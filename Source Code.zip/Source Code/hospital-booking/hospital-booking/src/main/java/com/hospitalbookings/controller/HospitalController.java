package com.hospitalbookings.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalbookings.entity.Hospital;
import com.hospitalbookings.payload.request.HospitalModel;
import com.hospitalbookings.payload.request.HospitalSlotsModel;
import com.hospitalbookings.payload.request.HospitalUpdateModel;
import com.hospitalbookings.service.HospitalService;

@RestController
@CrossOrigin
@RequestMapping("/api/hospitals")
public class HospitalController {

	private static final Logger logger = LoggerFactory.getLogger(HospitalController.class);
	
	@Autowired
	HospitalService hospitalService;
	
	@PostMapping
	public ResponseEntity<Hospital> addHospital(@RequestBody final HospitalModel model){
		logger.info("Add hospital controller triggered - Name : {}", model.getHospitalName());
		final Hospital hospital = hospitalService.saveNewHospital(model);
		logger.info("Add hospital controller completed - Name : {}", model.getHospitalName());
		return new ResponseEntity<>(hospital, HttpStatus.CREATED);
	}
	
	@GetMapping("/allhospitals")
	public ResponseEntity<?> getAllHospitals(@RequestParam(name = "search", defaultValue = "", required = false) String name){
		List<Hospital> hospitals = hospitalService.getAllHospitals(name);
		return new ResponseEntity<>(hospitals, HttpStatus.OK);
	}
	
	@DeleteMapping("/{hospitalId}/{userId}")
	public ResponseEntity<String> deleteHospitalById(@PathVariable long hospitalId, @PathVariable long userId){
		logger.info("Delete hospital controller triggered - hospitalId : {}, userId : {}", hospitalId,userId );
		hospitalService.deleteHospitalById(hospitalId, userId);
		logger.info("Delete hospital controller completed");
		return new ResponseEntity<>("Hospital deleted successfully", HttpStatus.OK);
	}
	
	@PutMapping("/{hospitalId}/{userId}")
	public ResponseEntity<Hospital> updateHospitalById(@PathVariable long hospitalId, @PathVariable long userId, @RequestBody HospitalUpdateModel model){
		logger.info("Update hospital controller triggered - hospitalId : {}, userId : {}", hospitalId, userId );
		Hospital hospital = hospitalService.updateHospitalById(hospitalId, userId, model);
		logger.info("Update hospital controller completed - hospitalId : {}, userId : {}", hospitalId, userId );
		return new ResponseEntity<>(hospital, HttpStatus.OK);
	}
	
	@GetMapping("/{hospitalId}")
	public ResponseEntity<Hospital> getHospitalById(@PathVariable long hospitalId){
		logger.info("Get hospital by Id controller triggered - hospitalId : {}",hospitalId);
		Hospital hospitals = hospitalService.getHospitalById(hospitalId);
		logger.info("Get hospital by Id controller completed - Matched Hospitals size : {}", hospitals);
		return new ResponseEntity<>(hospitals, HttpStatus.OK);
	}
	
	@PutMapping("/slots/{hospitalId}/{userId}")
	public ResponseEntity<Hospital> updateSlotsToHospitalById(@PathVariable long hospitalId, @PathVariable long userId, @RequestBody HospitalSlotsModel model){
		logger.info("Update hospital controller triggered - hospitalId : {}, userId : {}", hospitalId, userId );
		Hospital hospital = hospitalService.updateSlotsToHospitalById(hospitalId, userId, model);
		logger.info("Update hospital controller completed - hospitalId : {}, userId : {}", hospitalId, userId );
		return new ResponseEntity<>(hospital, HttpStatus.OK);
	}
	
	@DeleteMapping("/slots/{slotId}/{hospitalId}/{userId}")
	public ResponseEntity<Hospital> deleteHospitalSlotById(@PathVariable long slotId, @PathVariable long hospitalId, @PathVariable long userId){
		logger.info("Delete hospital slot controller triggered - hospitalId : {}, userId : {}", hospitalId,userId );
		Hospital hospital = hospitalService.deleteHospitalSlotById(slotId, hospitalId, userId);
		logger.info("Delete hospital slot controller completed");
		return new ResponseEntity<>(hospital, HttpStatus.OK);
	}
}
