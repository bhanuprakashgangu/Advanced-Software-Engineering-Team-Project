package com.hospitalbookings.payload.request;

import lombok.Data;

@Data
public class BookSlotModel {
	private long slotId;
	private long hospitalId;
	private long userId;
	private String message;
	private String paymentType;
	private String paymentId;
	private String status;
}
