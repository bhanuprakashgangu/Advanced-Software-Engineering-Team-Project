package com.hospitalbookings.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospitalbookings.entity.Slot;

@Repository
public interface HospitalSlotRepository extends JpaRepository<Slot, Long>{
List<Slot> findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(long hospitalId, String status, LocalDate date1, LocalDate date2);

List<Slot> findAllByAddedByIdOrderByDateAsc(long userId);
}
