package com.hospitalbookings.payload.request;

import lombok.Data;

@Data
public class SlotModel {
	private String date;
	private String startTime;
	private String endTime;
	private String service;
	private int amount;
}
