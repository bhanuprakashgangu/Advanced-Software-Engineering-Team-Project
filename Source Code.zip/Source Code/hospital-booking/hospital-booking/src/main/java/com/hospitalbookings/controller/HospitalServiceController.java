package com.hospitalbookings.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalbookings.entity.Service;
import com.hospitalbookings.payload.request.ServiceModel;
import com.hospitalbookings.service.ServiceService;

@RestController
@CrossOrigin
@RequestMapping("/api/service")
public class HospitalServiceController {
	
	private static final Logger logger = LoggerFactory.getLogger(HospitalServiceController.class);
	
	@Autowired
	ServiceService serviceService;
	
	@PostMapping
	public ResponseEntity<Service> addService(@RequestBody final ServiceModel serviceModel){
		logger.info("Add service controller triggered");
		final Service service = serviceService.addService(serviceModel);
		logger.info("Add service controller completed");
		return new ResponseEntity<>(service, HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Service>> getAllServices(){
		logger.info("Get all services controller triggered");
		final List<Service> service = serviceService.getAllServices();
		logger.info("Get all services controller completed");
		return new ResponseEntity<>(service, HttpStatus.OK);
	}
	
	@DeleteMapping("/{serviceId}/{userId}")
	public ResponseEntity<String> deleteServiceById(@PathVariable long serviceId, @PathVariable long userId){
		logger.info("Delete service controller triggered - serviceId : {} and userId : {}", serviceId, userId);
		serviceService.deleteServiceById(serviceId, userId);
		logger.info("Delete service controller - completed");
		return new ResponseEntity<>("Service deleted successfully", HttpStatus.OK);
	}
	
	@PutMapping("/{serviceId}")
	public ResponseEntity<Service> updateServiceById(@PathVariable long serviceId, @RequestBody final ServiceModel serviceModel){
		logger.info("Update service controller triggered - serviceId : {}", serviceId);
		Service service = serviceService.updateServiceById(serviceId, serviceModel);
		logger.info("Update service controller completed - serviceId : {}", serviceId);
		return new ResponseEntity<>(service, HttpStatus.OK);
	}
}
