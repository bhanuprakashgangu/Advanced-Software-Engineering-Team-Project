package com.hospitalbookings.payload.request;

import java.util.List;

import lombok.Data;

@Data
public class HospitalSlotsModel {
	 private List<SlotModel> slotList;
}
