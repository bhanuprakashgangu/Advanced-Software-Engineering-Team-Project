package com.hospitalbookings.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalbookings.entity.Hospital;
import com.hospitalbookings.entity.Service;
import com.hospitalbookings.entity.Slot;
import com.hospitalbookings.entity.Users;
import com.hospitalbookings.exception.HospitalBookingException;
import com.hospitalbookings.payload.request.HospitalModel;
import com.hospitalbookings.payload.request.HospitalSlotsModel;
import com.hospitalbookings.payload.request.HospitalUpdateModel;
import com.hospitalbookings.payload.request.SlotModel;
import com.hospitalbookings.repository.HospitalRepository;
import com.hospitalbookings.repository.HospitalServiceRepository;
import com.hospitalbookings.repository.UserRepository;

@org.springframework.stereotype.Service
public class HospitalService {

	@Autowired
	HospitalRepository hospitalRepo;
	
	@Autowired
	HospitalServiceRepository serviceRepo;
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	UserService userService;
	
	public Hospital saveNewHospital(HospitalModel model) {
		
		Optional<Users> userOptional = userRepo.findById(model.getUserId());
		if(userOptional.isPresent() && userOptional.get().getRole().equals("admin")) {
			Hospital hospital = new Hospital();
			hospital.setAddedAt(new Date());
			hospital.setAddedBy(userOptional.get());
			hospital.setCity(model.getCity().trim());
			hospital.setCountry(model.getCountry().trim());
			hospital.setModifiedAt(new Date());
			hospital.setModifiedBy(model.getUserId());
			hospital.setName(model.getHospitalName().trim());
			hospital.setState(model.getState().trim());
			hospital.setStreet(model.getStreet().trim());
			hospital.setZipcode(model.getZipcode().trim());
		
			List<Service> serviceList = new ArrayList<>();
			for(String serviceModel : model.getServiceList()) {
				Service service = serviceRepo.findByName(serviceModel);
				serviceList.add(service);
			}
			hospital.setServices(serviceList);
			
			List<Slot> slotList = new LinkedList<>();
			for(SlotModel slotModel : model.getSlotList()) {
				Slot slot = new Slot();
				slot.setService(serviceRepo.findByName(slotModel.getService()));
				slot.setAddedBy(userOptional.get());
				slot.setDate(LocalDate.parse(slotModel.getDate()));
				slot.setStartTime(slotModel.getStartTime());
				slot.setEndTime(slotModel.getEndTime());
				slot.setAmount(slotModel.getAmount());
				slot.setHospital(hospital);
				slot.setStatus("AVAILABLE");
				slotList.add(slot);
			}
			hospital.setServices(serviceList);
			hospital.setSlots(slotList);
			return hospitalRepo.save(hospital);
		} else {
			throw new HospitalBookingException("User dont have permission to add new hospital!");
		}
	}

	public List<Hospital> getAllHospitals(String name) {
		if(name==null || (name!= null && name.trim().equals(""))) {
			return hospitalRepo.findAll();
		}
		return hospitalRepo.findDistinctByNameContainingIgnoreCaseOrCityContainingIgnoreCaseOrServicesNameContainingIgnoreCaseOrderByAddedAtDesc(name, name, name);
	}

	public Hospital updateHospitalById(long hospitalId, long userId, HospitalUpdateModel model) {
		Optional<Users> userOptional = userRepo.findById(userId);
		Optional<Hospital> hospitalOptional = hospitalRepo.findById(hospitalId);
		if(userOptional.isPresent() && userOptional.get().getRole().equals("admin") && hospitalOptional.isPresent()) {
			Hospital hospital = hospitalOptional.get();
			if(!hospital.getName().equals(model.getHospitalName().trim())) {
				hospital.setName(model.getHospitalName().trim());
			}
			if(!hospital.getStreet().equals(model.getStreet().trim())) {
				hospital.setStreet(model.getStreet().trim());
			}
			if(!hospital.getCity().equals(model.getCity().trim())) {
				hospital.setCity(model.getCity().trim());
			}
			if(!hospital.getState().equals(model.getState().trim())) {
				hospital.setState(model.getState().trim());
			}
			if(!hospital.getCountry().equals(model.getCountry().trim())) {
				hospital.setCountry(model.getCountry().trim());
			}
			if(!hospital.getZipcode().equals(model.getZipcode().trim())) {
				hospital.setZipcode(model.getZipcode().trim());
			}
			List<Service> serviceList = new ArrayList<>();
			for(String serviceModel : model.getServiceList()) {
					Service service = serviceRepo.findByName(serviceModel);
					serviceList.add(service);
			}
			hospital.setServices(serviceList);
			List<String> serviceListInDb = hospital.getServices().stream().map(Service::getName).collect(Collectors.toList());
			List<Slot> servicesFromDb = hospital.getSlots().stream().filter(each -> (!serviceListInDb.contains(each.getService().getName()))).collect(Collectors.toList());
			hospital.getSlots().removeAll(servicesFromDb);
			return hospitalRepo.save(hospital);
		} else {
			throw new HospitalBookingException("User dont have permission to update hospital!");
		}
	}

	public void deleteHospitalById(long hospitalId, long userId) {
		Optional<Users> userOptional = userRepo.findById(userId);
		Optional<Hospital> hospitalOptional = hospitalRepo.findById(hospitalId);
		if(userOptional.isPresent() && userOptional.get().getRole().equals("admin") && hospitalOptional.isPresent()) {
			hospitalRepo.delete(hospitalOptional.get());
		} else {
			throw new HospitalBookingException("User dont have permission to delete hospital!");
		}
	}

	public Hospital getHospitalById(long hospitalId) {
		Optional<Hospital> hospitalOptional = hospitalRepo.findByIdOrderBySlotsDateAsc(hospitalId);
		System.out.println(hospitalOptional.get().getSlots());
		return hospitalOptional.isPresent()?hospitalOptional.get():null;
	}

	public Hospital updateSlotsToHospitalById(long hospitalId, long userId, HospitalSlotsModel model) {
		Optional<Users> userOptional = userRepo.findById(userId);
		Optional<Hospital> hospitalOptional = hospitalRepo.findById(hospitalId);
		if(userOptional.isPresent() && userOptional.get().getRole().equals("admin") && hospitalOptional.isPresent()) {
			Hospital hospital = hospitalOptional.get();
			List<Slot> slotList = new LinkedList<>();
			for(SlotModel slotModel : model.getSlotList()) {
				Slot slot = new Slot();
				slot.setService(serviceRepo.findByName(slotModel.getService()));
				slot.setAddedBy(userOptional.get());
				slot.setDate(LocalDate.parse(slotModel.getDate()));
				slot.setStartTime(slotModel.getStartTime());
				slot.setEndTime(slotModel.getEndTime());
				slot.setAmount(slotModel.getAmount());
				slot.setHospital(hospital);
				slot.setStatus("AVAILABLE");
				slotList.add(slot);
			}
			hospital.getSlots().addAll(slotList);
			return hospitalRepo.save(hospital);
		} else {
			throw new HospitalBookingException("User dont have permission to update hospital!");
		}
	}

	public Hospital deleteHospitalSlotById(long slotId, long hospitalId, long userId) {
		Optional<Users> userOptional = userRepo.findById(userId);
		Optional<Hospital> hospitalOptional = hospitalRepo.findById(hospitalId);
		if(userOptional.isPresent() && userOptional.get().getRole().equals("admin") && hospitalOptional.isPresent()) {
			Hospital hospital = hospitalOptional.get();
			Optional<Slot> slotOption = hospital.getSlots().stream().filter(each -> (slotId == each.getId())).findAny();
			if(slotOption.isPresent()) {
				Slot slot = slotOption.get();
				hospital.getSlots().remove(slot);
				return hospitalRepo.save(hospital);
			}
		} else {
			throw new HospitalBookingException("User dont have permission to update hospital!");
		}
		return null;
	}
}
