package com.hospitalbookings.payload.request;

import java.util.List;

import lombok.Data;

@Data
public class HospitalModel {
	private long userId;
	private String hospitalName;
	private String street;
	private String city;
	private String state;
	private String zipcode;
	private String country;
    private List<String> serviceList;
    private List<SlotModel> slotList;
}
