package com.hospitalbookings.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalbookings.entity.Users;
import com.hospitalbookings.exception.HospitalBookingException;
import com.hospitalbookings.payload.request.LoginRequest;
import com.hospitalbookings.payload.request.SignupRequest;
import com.hospitalbookings.payload.response.MessageResponse;
import com.hospitalbookings.payload.response.UserInfoResponse;
import com.hospitalbookings.repository.UserRepository;
import com.hospitalbookings.security.jwt.SecurityHelper;
import com.hospitalbookings.security.services.UserDetailsImpl;
import com.hospitalbookings.security.services.UserDetailsServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("/api/auth")
public class AuthController {
  @Autowired
  AuthenticationManager authenticationManager;

  @Autowired
  UserRepository userRepository;

  @Autowired
  SecurityHelper jwtUtils;
  
  @Autowired
  UserDetailsServiceImpl userDetailsServiceImpl;

  @PostMapping("/signin")
  public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
    Authentication authentication = authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

    SecurityContextHolder.getContext().setAuthentication(authentication);

    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

    String jwtToken = jwtUtils.generateJwtCookie(userDetails);
    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtToken.toString())
        .body(new UserInfoResponse(userDetails.getId(),
                                   userDetails.getFirstName(),userDetails.getLastName(),
                                   userDetails.getEmail(), jwtToken, userDetails.getRole()));
  }

  @PostMapping("/signup")
  public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
    if (userRepository.findByEmail(signUpRequest.getEmail()).isPresent()) {
      throw new HospitalBookingException("Email already used by another user");
    }
    // Create new user's account
    Users user = new Users(signUpRequest.getFirstName(), signUpRequest.getLastName(), 
                         signUpRequest.getEmail(),
                         signUpRequest.getPassword(),
                         signUpRequest.getRole());

    userRepository.save(user);

    return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
  }
}
