package com.hospitalbookings.service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalbookings.entity.Hospital;
import com.hospitalbookings.entity.Slot;
import com.hospitalbookings.entity.SlotBooking;
import com.hospitalbookings.entity.Users;
import com.hospitalbookings.exception.HospitalBookingException;
import com.hospitalbookings.payload.request.BookSlotModel;
import com.hospitalbookings.payload.response.SlotBookingResponse;
import com.hospitalbookings.repository.HospitalRepository;
import com.hospitalbookings.repository.HospitalSlotBookingRepository;
import com.hospitalbookings.repository.HospitalSlotRepository;
import com.hospitalbookings.repository.UserRepository;

@Service
public class SlotService {

	@Autowired
	HospitalSlotRepository slotRepo;

	@Autowired
	HospitalRepository hospitalRepo;

	@Autowired
	UserRepository userRepo;

	@Autowired
	HospitalSlotBookingRepository slotBookingRepo;

	@Autowired
	EmailService emailService;

	public List<Slot> searchSlotsBetweenDates(long hospitalId, LocalDate sdate, LocalDate edate) {
		List<Slot> list = slotRepo
				.findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(hospitalId,
						"AVAILABLE", edate, sdate);
		return list;
	}

	public SlotBooking bookSlot(BookSlotModel model) throws MessagingException, IOException {
		Optional<Hospital> hospitalOptional = hospitalRepo.findById(model.getHospitalId());
		Optional<Users> userOptional = userRepo.findById(model.getUserId());
		Optional<Slot> slotOptional = slotRepo.findById(model.getSlotId());
		if (hospitalOptional.isPresent() && userOptional.isPresent() && slotOptional.isPresent()) {
			Hospital hospital = hospitalOptional.get();
			hospital.getSlots().stream().filter(each -> each.getId() == model.getSlotId()).findFirst().get()
					.setStatus(model.getStatus());
			hospitalRepo.save(hospital);
			SlotBooking sbook = new SlotBooking();
			sbook.setBookedBy(userOptional.get());
			sbook.setBookedDate(LocalDateTime.now());
			sbook.setMessage(model.getMessage());
			sbook.setPaymentType(model.getPaymentType());
			sbook.setPaymentId(model.getPaymentId());
			sbook.setSlot(slotOptional.get());
			sbook.setStatus(model.getStatus());
			SlotBooking slotBooking = slotBookingRepo.save(sbook);
			sendEmail(sbook, slotOptional.get());
			return slotBooking;
		} else {
			throw new HospitalBookingException("Internal server error!");
		}
	}

	public void sendEmail(SlotBooking book, Slot slot) throws MessagingException, IOException {
		String subject = "";
		Map<Object, Object> emailMap = new LinkedHashMap<>();
		subject = "Your appoinment slot booking - " + book.getStatus().toUpperCase();
		emailMap.put("Hospital name", slot.getHospital().getName());
		emailMap.put("Service", slot.getService().getName());
		emailMap.put("Message", book.getMessage());
		emailMap.put("Date", slot.getDate());
		emailMap.put("Start Time", slot.getStartTime());
		emailMap.put("End Time", slot.getEndTime());
		emailMap.put("Amount", slot.getAmount());
		emailMap.put("Status", book.getStatus());
		emailMap.put("Requestor", book.getBookedBy().getFirstName() + " " + book.getBookedBy().getLastName());
		emailService.sendEmail(new String[] { book.getBookedBy().getEmail() }, subject, emailMap);
	}

	public List<SlotBookingResponse> getAllBookings(long userId) {
		List<SlotBooking> list = slotBookingRepo.findAllSlotByBookedByIdOrderByBookedDateDesc(userId);
		List<SlotBookingResponse> res = new LinkedList<>();
		for (SlotBooking book : list) {
			Slot each = book.getSlot();
			res.add(new SlotBookingResponse(each.getHospital().getName(), each.getService().getName(), each.getDate(),
					each.getStartTime(), each.getEndTime(), book.getStatus(), each.getAmount(), each.getId()));
		}
		return res;
	}

	public SlotBooking cancelSlot(long slotId, long userId) {
		Optional<Slot> slotOptional = slotRepo.findById(slotId);
		if (slotOptional.isPresent()) {
			Slot slot = slotOptional.get();
			Hospital hospital = slot.getHospital();
			hospital.getSlots().stream().filter(each -> each.getId() == slot.getId()).findFirst().get()
					.setStatus("AVAILABLE");
			hospitalRepo.save(hospital);
			SlotBooking sbook = slotBookingRepo.findBySlotId(slotId);
			sbook.setBookedDate(LocalDateTime.now());
			sbook.setPaymentType("-");
			sbook.setPaymentId("-");
			sbook.setStatus("CANCELLED");
			return slotBookingRepo.save(sbook);
		} else {
			throw new HospitalBookingException("Internal server error!");
		}
	}

}
