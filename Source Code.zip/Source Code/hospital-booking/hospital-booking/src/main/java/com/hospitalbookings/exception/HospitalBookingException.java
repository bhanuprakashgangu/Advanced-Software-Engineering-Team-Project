package com.hospitalbookings.exception;

public class HospitalBookingException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public HospitalBookingException(String errorMessage) {  
    	super(errorMessage);  
    } 
	
}
