package com.hospitalbookings.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
public class SlotBooking {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@OneToOne
	@JoinColumn(name="slot_id")
	private Slot slot;
	
	@OneToOne
	@JoinColumn(name = "booked_by")
	private Users bookedBy;
	
	@Column(length = 1000)
	private String message;
	
	private String paymentType;
	
	private String paymentId;
	
	private String status;
	
	private LocalDateTime bookedDate;

}
