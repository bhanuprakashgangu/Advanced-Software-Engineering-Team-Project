package com.hospitalbookings.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Entity
@NoArgsConstructor
public class Hospital {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name="name", unique = true)
	private String name;
	private String street;
	private String city;
	private String state;
	private String country;
	private String zipcode;
	@OneToOne
	@JoinColumn(name = "added_by")
	private Users addedBy;
    private long modifiedBy;
    private Date addedAt;
    private Date modifiedAt;
    
    @OneToMany(mappedBy = "hospital", orphanRemoval = true, targetEntity = Slot.class, cascade = CascadeType.ALL)
	private List<Slot> slots;
	
	@ManyToMany(targetEntity = Service.class, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinTable(name="hospital_service_map", 
			joinColumns = {
					@JoinColumn(name = "hospitalId", referencedColumnName = "id")}, inverseJoinColumns = {
					@JoinColumn(name = "serviceId", referencedColumnName = "id")
			})
	private List<Service> services;

}