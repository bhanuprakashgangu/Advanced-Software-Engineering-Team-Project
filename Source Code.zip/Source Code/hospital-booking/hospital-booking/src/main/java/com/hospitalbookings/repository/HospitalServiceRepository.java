package com.hospitalbookings.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospitalbookings.entity.Service;
@Repository
public interface HospitalServiceRepository extends JpaRepository<Service, Long>{
	Service findByName(String name);
}
