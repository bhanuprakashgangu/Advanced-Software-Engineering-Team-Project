package com.hospitalbookings.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalbookings.entity.Users;
import com.hospitalbookings.repository.UserRepository;

@Service
public class UserService {
	
	private static final Logger logger = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	UserRepository userRepo;
	
	public boolean isAdmin(long id) {
		logger.info("Checking user is admin : userId : {}", id);
		Optional<Users> user = userRepo.findById(id);
		return (user!=null) ? user.get().getRole().equals("admin") : false;
	}
}
