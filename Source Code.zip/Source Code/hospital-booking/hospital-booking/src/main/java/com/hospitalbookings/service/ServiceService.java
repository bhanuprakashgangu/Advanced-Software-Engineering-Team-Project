package com.hospitalbookings.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hospitalbookings.entity.Service;
import com.hospitalbookings.exception.HospitalBookingException;
import com.hospitalbookings.payload.request.ServiceModel;
import com.hospitalbookings.repository.HospitalServiceRepository;

@org.springframework.stereotype.Service
public class ServiceService {
private static final Logger logger = LoggerFactory.getLogger(ServiceService.class);
	
	@Autowired
	HospitalServiceRepository serviceRepo;
	
	@Autowired
	UserService userService;

	public Service addService(ServiceModel serviceModel) {
		if(!userService.isAdmin(serviceModel.getUserId())) {
			throw new HospitalBookingException("User dont have permission to add service");
		}
		logger.info("User has admin access to add service- userId : {}", serviceModel.getUserId());
		Service service = new Service();
		service.setAddedBy(serviceModel.getUserId());
		service.setModifiedBy(serviceModel.getUserId());
		service.setAddedAt(new Date());
		service.setModifiedAt(new Date());
		service.setName(serviceModel.getName().trim());
		return serviceRepo.save(service);
	}

	public List<Service> getAllServices() {
		logger.info("get All Services successfully triggered");
		List<Service> serviceList = serviceRepo.findAll();
		return serviceList;
	}

	public Service updateServiceById(long serviceId, ServiceModel serviceModel) {
		if(!userService.isAdmin(serviceModel.getUserId())) {
			logger.error("User dont have permission to add service - userId : {}", serviceModel.getUserId());
			throw new HospitalBookingException("User dont have permission to update service");
		}
		logger.info("User has admin access - userId : {}", serviceModel.getUserId());
		Optional<Service> optional = serviceRepo.findById(serviceId);
		if(optional.isPresent()) {
			Service service = optional.get();
			if(!service.getName().equalsIgnoreCase(serviceModel.getName().trim()))
				service.setName(serviceModel.getName());
			service.setModifiedAt(new Date());
			service.setModifiedBy(serviceModel.getUserId());
			return serviceRepo.save(service);
		} else {
			logger.error("Service not found - serviceId : {}", serviceId);
			throw new HospitalBookingException("Service not found");
		}
	}

	public void deleteServiceById(long serviceId, long userId) {
		if(!userService.isAdmin(userId)) {
			logger.error("User dont have permission to delete service - userId : {}", userId);
			throw new HospitalBookingException("User dont have permission to delete service");
		}
		logger.info("User has admin access - userId : {}", userId);
		try {
			serviceRepo.deleteById(serviceId);
		} catch(Exception exp) {
			logger.error("Service already mapped to patients : {}", exp.getMessage());
			throw new HospitalBookingException("Service already mapped to hospitals");
		}
		
	}
}
