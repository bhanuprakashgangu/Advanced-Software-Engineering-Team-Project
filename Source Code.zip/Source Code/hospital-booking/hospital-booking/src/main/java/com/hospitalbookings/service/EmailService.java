package com.hospitalbookings.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import biweekly.Biweekly;
import biweekly.ICalendar;
import biweekly.component.VEvent;
import biweekly.parameter.ParticipationLevel;
import biweekly.property.Attendee;
import biweekly.property.Method;
import biweekly.property.Organizer;
import biweekly.util.Duration;

@Service
public class EmailService {

	@Autowired
	private JavaMailSender javaMailSender;

	@Async
	public void sendEmail(String[] emails, String subject, Map<Object, Object> data)
			throws MessagingException, IOException {
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper msg = new MimeMessageHelper(message, true);
		msg.setTo(emails);
		msg.setSubject(subject);

		String text = "<html><head><style>table {font-family: arial, sans-serif; border-collapse: collapse; width: 100%;} td, th { border: 1px solid #dddddd; text-align: left; padding: 8px;}</style></head><body>"
				+ "Dear " + data.get("Requestor") + ",<br></br><br></br> Your appointment booking request status:"
				+ "<table style='font-family: arial, sans-serif;border-collapse: collapse;width: 100%;'>"
				+ "<tr><th>Hospital Name</th><th>Service Name</th><th>Date</th><th>Start Time</th><th>End Time</th><th>Amount</th><th>Status</th></tr>"
				+ "<tr><td>" + data.get("Hospital name") + "</td>" + "<td>" + data.get("Service") + "</td>" + "<td>"
				+ data.get("Date") + "</td>" + "<td>" + data.get("Start Time") + "</td>" + "<td>" + data.get("End Time")
				+ "</td>" + "<td>" + data.get("Amount") + "</td>" + "<td>" + data.get("Status") + "</td>"
				+ "</tr></table>" + "<br></br>Thanks, <br></br>Medi bookings Team" + "</body></html>";

		DataSource iCalData = null;
		try {
			iCalData = new ByteArrayDataSource(generateICalData(data), "text/calendar; charset=UTF-8");
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
		message.setDataHandler(new DataHandler(iCalData));
		message.setHeader("Content-Type", "text/calendar; charset=UTF-8; method=REQUEST");
		msg.setText(text, true);

		javaMailSender.send(message);

	}

	public static String generateICalData(Map<Object, Object> data) throws ParseException {
		ICalendar ical = new ICalendar();
		ical.addProperty(new Method(Method.REQUEST));

		VEvent event = new VEvent();
		event.setSummary(data.get("Hospital name") + "-" + data.get("Service") + "-INVITE");
		event.setDescription((String) data.get("Message"));

		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		TimeZone zone = TimeZone.getTimeZone(ZoneId.systemDefault());
		formatter1.setTimeZone(zone);
		LocalDate ldate = (LocalDate) data.get("Date");

		Date date = Date.from(ldate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
		sdf.setTimeZone(zone);
		Date stime = sdf.parse((String) data.get("Start Time"));

		date.setHours(stime.getHours());
		date.setMinutes(stime.getMinutes());
		event.setDateStart(date);

		Date etime = sdf.parse((String) data.get("End Time"));

		long difference_In_Time = etime.getTime() - stime.getTime();

		int difference_In_Hours = (int) ((difference_In_Time / (1000 * 60 * 60)) % 24);

		event.setDuration(new Duration.Builder().hours(difference_In_Hours).build());

		event.setOrganizer(new Organizer("Hospital booking Team", "hospitalbooking@domain"));

		Attendee a = new Attendee("Hospital booking Team", "hospitalbooking@domain");
		a.setParticipationLevel(ParticipationLevel.REQUIRED);
		event.addAttendee(a);
		ical.addEvent(event);

		return Biweekly.write(ical).go();
	}

}
