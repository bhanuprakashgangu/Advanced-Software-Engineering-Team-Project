package com.hospitalbookings.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospitalbookings.entity.SlotBooking;

@Repository
public interface HospitalSlotBookingRepository  extends JpaRepository<SlotBooking, Long>{

	List<SlotBooking> findAllSlotByBookedByIdOrderByBookedDateDesc(long userId);

	SlotBooking findBySlotId(long slotId);

}
