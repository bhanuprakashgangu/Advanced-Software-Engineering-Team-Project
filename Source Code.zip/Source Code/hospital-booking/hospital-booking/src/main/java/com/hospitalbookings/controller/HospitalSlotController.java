package com.hospitalbookings.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalbookings.entity.Slot;
import com.hospitalbookings.entity.SlotBooking;
import com.hospitalbookings.payload.request.BookSlotModel;
import com.hospitalbookings.payload.response.SlotBookingResponse;
import com.hospitalbookings.service.SlotService;

@RestController
@CrossOrigin
@RequestMapping("/api/slot")
public class HospitalSlotController {
	
	@Autowired
	SlotService slotService;
	
	@GetMapping("/{hospitalId}/{sdate}/{edate}")
	public ResponseEntity<?> getAllHospitals(@PathVariable long hospitalId, @PathVariable("sdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate sdate, 
			@PathVariable("edate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate edate){
		List<Slot> slots = slotService.searchSlotsBetweenDates(hospitalId, sdate,edate);
		return new ResponseEntity<>(slots, HttpStatus.OK);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<?> getAllBookings(@PathVariable long userId){
		List<SlotBookingResponse> slots = slotService.getAllBookings(userId);
		return new ResponseEntity<>(slots, HttpStatus.OK);
	}
	
	@PostMapping("/book")
	public ResponseEntity<?> bookSlot(@RequestBody BookSlotModel model) throws MessagingException, IOException{
		SlotBooking slots = slotService.bookSlot(model);
		return new ResponseEntity<>(slots, HttpStatus.OK);
	}
	
	@PostMapping("/cancel/{slotId}/{userId}")
	public ResponseEntity<?> bookSlot(@PathVariable long slotId, @PathVariable long userId) throws MessagingException, IOException{
		SlotBooking slot = slotService.cancelSlot(slotId, userId);
		return new ResponseEntity<>(slot, HttpStatus.OK);
	}
}
