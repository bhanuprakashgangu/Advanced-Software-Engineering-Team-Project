package com.hospitalbookings.payload.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ServiceModel {
	private int userId;
	private String name;
}
