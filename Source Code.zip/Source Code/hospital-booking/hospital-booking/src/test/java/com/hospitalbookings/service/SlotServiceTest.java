package com.hospitalbookings.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hospitalbookings.entity.Hospital;
import com.hospitalbookings.entity.Service;
import com.hospitalbookings.entity.Slot;
import com.hospitalbookings.entity.SlotBooking;
import com.hospitalbookings.entity.Users;
import com.hospitalbookings.payload.request.BookSlotModel;
import com.hospitalbookings.payload.request.HospitalModel;
import com.hospitalbookings.payload.request.ServiceModel;
import com.hospitalbookings.payload.request.SlotModel;
import com.hospitalbookings.payload.response.SlotBookingResponse;
import com.hospitalbookings.repository.HospitalRepository;
import com.hospitalbookings.repository.HospitalServiceRepository;
import com.hospitalbookings.repository.HospitalSlotBookingRepository;
import com.hospitalbookings.repository.HospitalSlotRepository;
import com.hospitalbookings.repository.UserRepository;
import com.hospitalbookings.service.EmailService;
import com.hospitalbookings.service.SlotService;
import com.hospitalbookings.service.UserService;
import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SlotServiceTest {
	@InjectMocks
	private SlotService slotService;

	@Mock
	private HospitalRepository hospitalRepo;
	@Mock
	HospitalServiceRepository serviceRepo;
	
	@Mock
	UserRepository userRepo;
	
	@Mock
	UserService userService;	
	
	@Mock
	HospitalSlotRepository slotRepo;
	
	@Mock
	HospitalSlotBookingRepository slotBookingRepo;
	
	@Mock 
	EmailService emailService;
	
	@Test
	void searchSlotsBetweenDates() throws Exception {
		List<Slot> slotList = new ArrayList<>();
		slotList.add(getSlotObject());
		Mockito.when(slotRepo.findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(any(Long.class),any(String.class),any(LocalDate.class),any(LocalDate.class))).thenReturn(slotList);
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(userService.isAdmin(any(Long.class))).thenReturn(true);
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		List<Slot> dto = slotService.searchSlotsBetweenDates(1, LocalDate.now(), LocalDate.now());
		assertThat(dto.size()).isEqualTo(1);
	}
	
	@Test
	void bookSlot() throws Exception {
		List<Slot> slotList = new ArrayList<>();
		slotList.add(getSlotObject());
		Mockito.doNothing().when(emailService).sendEmail(any(String[].class), any(String.class), any(HashMap.class));
		Mockito.when(slotRepo.findById(any(Long.class))).thenReturn(Optional.of(getSlotObject()));
		Mockito.when(slotRepo.findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(any(Long.class),any(String.class),any(LocalDate.class),any(LocalDate.class))).thenReturn(slotList);
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getUserUserObject()));
		Mockito.when(userService.isAdmin(any(Long.class))).thenReturn(true);
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Mockito.when(slotBookingRepo.save(any(SlotBooking.class))).thenReturn(formSlotBooking());
		SlotBooking dto = slotService.bookSlot(formBookSlotModel());
		assertThat(dto.getPaymentId()).isEqualTo("test");
	}
	
	@Test
	void getAllBookings() throws Exception {
		List<Slot> slotList = new ArrayList<>();
		slotList.add(getSlotObject());
		Mockito.doNothing().when(emailService).sendEmail(any(String[].class), any(String.class), any(HashMap.class));
		Mockito.when(slotRepo.findById(any(Long.class))).thenReturn(Optional.of(getSlotObject()));
		Mockito.when(slotRepo.findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(any(Long.class),any(String.class),any(LocalDate.class),any(LocalDate.class))).thenReturn(slotList);
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getUserUserObject()));
		Mockito.when(userService.isAdmin(any(Long.class))).thenReturn(true);
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Mockito.when(slotBookingRepo.save(any(SlotBooking.class))).thenReturn(formSlotBooking());
		List<SlotBooking> list = new ArrayList<>();
		list.add(formSlotBooking());
		Mockito.when(slotBookingRepo.findAllSlotByBookedByIdOrderByBookedDateDesc(any(Long.class))).thenReturn(list);
		List<SlotBookingResponse> dto = slotService.getAllBookings(1);
		assertThat(dto.size()).isEqualTo(1);
	}
	
	@Test
	void cancelSlot() throws Exception {
		List<Slot> slotList = new ArrayList<>();
		slotList.add(getSlotObject());
		Mockito.doNothing().when(emailService).sendEmail(any(String[].class), any(String.class), any(HashMap.class));
		Mockito.when(slotRepo.findById(any(Long.class))).thenReturn(Optional.of(getSlotObject()));
		Mockito.when(slotRepo.findAllByHospitalIdAndStatusAndDateLessThanEqualAndDateGreaterThanEqualOrderByDateAsc(any(Long.class),any(String.class),any(LocalDate.class),any(LocalDate.class))).thenReturn(slotList);
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getUserUserObject()));
		Mockito.when(userService.isAdmin(any(Long.class))).thenReturn(true);
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Mockito.when(slotBookingRepo.save(any(SlotBooking.class))).thenReturn(formSlotBooking());
		Mockito.when(slotBookingRepo.findBySlotId(any(Long.class))).thenReturn(formSlotBooking());
		List<SlotBooking> list = new ArrayList<>();
		list.add(formSlotBooking());
		Mockito.when(slotBookingRepo.findAllSlotByBookedByIdOrderByBookedDateDesc(any(Long.class))).thenReturn(list);
		SlotBooking dto = slotService.cancelSlot(2,1);
		assertThat(dto.getPaymentId()).isEqualTo("test");
	}
	
	private Service getServicesObject() {
		Service service = new Service();
		service.setAddedAt(new Date());
		service.setAddedBy(1);
		service.setId(1L);
		service.setModifiedAt(new Date());
		service.setModifiedBy(1);
		service.setName("test service");
		return service;
	}
	
	private SlotBooking formSlotBooking() {
		SlotBooking book = new SlotBooking();
		book.setBookedBy(getAdminUserObject());
		book.setBookedDate(LocalDateTime.now());
		book.setPaymentId("test");
		book.setPaymentType("CREDIT");
		book.setSlot(getSlotObject());
		book.setStatus("BOOKED");
		return book;
	}
	
	private Users getAdminUserObject() {
		Users user = new Users();
		user.setEmail("admin@gmail.com");
		user.setFirstName("test");
		user.setLastName("test");
		user.setId(1L);
		user.setRole("admin");
		return user;
	}
	
	private Users getUserUserObject() {
		Users user = new Users();
		user.setEmail("user@gmail.com");
		user.setFirstName("test");
		user.setLastName("user");
		user.setId(2L);
		user.setRole("user");
		return user;
	}
	
	private Slot getSlotObject() {
		Slot slot = new Slot();
		slot.setAddedBy(getAdminUserObject());
		slot.setAmount(10);
		slot.setDate(LocalDate.now());
		slot.setId(2L);
		slot.setStartTime("09:00");
		slot.setEndTime("10:00");
		slot.setService(getServicesObject());
		Hospital hospital = new Hospital();
		hospital.setId(1L);
		hospital.setName("test");
		List<Slot> slots = new ArrayList<>();
		Slot slot1 = new Slot();
		slot1.setAddedBy(getAdminUserObject());
		slot1.setAmount(10);
		slot1.setDate(LocalDate.now());
		slot1.setId(2L);
		slot1.setStartTime("09:00");
		slot1.setEndTime("10:00");
		slots.add(slot1);
		hospital.setSlots(slots);
		slot.setHospital(hospital);
		slot.setStatus("AVAILABLE");
		return slot;
	}
	
	private Hospital getHospitalObject() {
		Hospital hospital = new Hospital();
		hospital.setAddedAt(new Date());
		hospital.setAddedBy(getAdminUserObject());
		hospital.setCity("test");
		hospital.setCountry("test");
		hospital.setName("test");
		hospital.setZipcode("test");
		hospital.setStreet("test");
		hospital.setState("test");
		hospital.setModifiedAt(new Date());
		hospital.setId(1L);
		List<Service> list = new ArrayList<>();
		list.add(getServicesObject());
		hospital.setServices(list);
		
		List<Slot> slots = new ArrayList<>();
		slots.add(getSlotObject());
		hospital.setSlots(slots);
		
		return hospital;
	}
	
	private HospitalModel formHospitalModel() {
		HospitalModel model = new HospitalModel();
		model.setCity("test");
		model.setCountry("test");
		model.setHospitalName("test");
		model.setState("test");
		model.setZipcode("test");
		model.setStreet("test");
		List<String> list = new ArrayList<>();
		list.add("test");
		model.setServiceList(list);
		
		SlotModel smodel = new SlotModel();
		smodel.setDate("2022-10-22");
		smodel.setAmount(10);
		smodel.setEndTime("10:00");
		smodel.setStartTime("11:00");
		smodel.setService("test");
		List<SlotModel> slt = new ArrayList<>();
		slt.add(smodel);
		model.setSlotList(slt);
		return model;
	}
	
	private ServiceModel formServiceModel() {
		ServiceModel model = new ServiceModel();
		model.setName("update");
		model.setUserId(1);
		return model;
	}
	
	public BookSlotModel formBookSlotModel() {
		BookSlotModel model = new BookSlotModel();
		model.setHospitalId(1L);
		model.setPaymentId("test");
		model.setPaymentType("CREDIT");
		model.setSlotId(2L);
		model.setStatus("AVAILABLE");
		model.setUserId(1L);
		return model;
	}
}
