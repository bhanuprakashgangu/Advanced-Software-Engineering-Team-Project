package com.hospitalbookings.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hospitalbookings.entity.Users;
import com.hospitalbookings.repository.UserRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTest {
	@InjectMocks
	private UserService userService;

	@Mock
	UserRepository userRepo;
	
	@Test
	void isAdmin() throws Exception {
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		boolean dto = userService.isAdmin(1);
		assertThat(dto).isEqualTo(true);
	}
	
	private Users getAdminUserObject() {
		Users user = new Users();
		user.setEmail("admin@gmail.com");
		user.setFirstName("test");
		user.setLastName("test");
		user.setId(1L);
		user.setRole("admin");
		return user;
	}
	
}
