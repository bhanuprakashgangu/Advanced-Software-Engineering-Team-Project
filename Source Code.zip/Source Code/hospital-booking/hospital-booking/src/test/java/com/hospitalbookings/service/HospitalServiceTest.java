package com.hospitalbookings.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.hospitalbookings.entity.Hospital;
import com.hospitalbookings.entity.Service;
import com.hospitalbookings.entity.Slot;
import com.hospitalbookings.entity.Users;
import com.hospitalbookings.payload.request.HospitalModel;
import com.hospitalbookings.payload.request.HospitalSlotsModel;
import com.hospitalbookings.payload.request.HospitalUpdateModel;
import com.hospitalbookings.payload.request.SlotModel;
import com.hospitalbookings.repository.HospitalRepository;
import com.hospitalbookings.repository.HospitalServiceRepository;
import com.hospitalbookings.repository.UserRepository;
import com.hospitalbookings.service.HospitalService;
import com.hospitalbookings.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HospitalServiceTest {

	@InjectMocks
	private HospitalService hospitalService;

	@Mock
	private HospitalRepository hospitalRepo;
	@Mock
	HospitalServiceRepository serviceRepo;
	
	@Mock
	UserRepository userRepo;
	
	@Mock
	UserService userService;
	
	@Test
	void addHospital() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Hospital dto = hospitalService.saveNewHospital(formHospitalModel());
		assertThat(dto.getName()).isEqualTo("test");
	}
	
	@Test
	void updateHospital() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Hospital dto = hospitalService.updateHospitalById(1,1,formHospitalUpdateModel());
		assertThat(dto.getName()).isEqualTo("test");
	}
	
	@Test
	void updateSlotsToHospitalById() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Hospital dto = hospitalService.updateSlotsToHospitalById(1,1,formHospitalSlotsModel());
		assertThat(dto.getName()).isEqualTo("test");
	}
	
	@Test
	void deleteHospitalSlotById() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.when(hospitalRepo.save(any(Hospital.class))).thenReturn(getHospitalObject());
		Hospital dto = hospitalService.deleteHospitalSlotById(2,1,1);
		assertThat(dto.getName()).isEqualTo("test");
	}

	@Test
	void deleteHospital() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.findById(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.doNothing().when(hospitalRepo).delete(any(Hospital.class));
		hospitalService.deleteHospitalById(1,1);
	}
	
	@Test
	void getHospitalById() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		Mockito.when(hospitalRepo.findByIdOrderBySlotsDateAsc(any(Long.class))).thenReturn(Optional.of(getHospitalObject()));
		Mockito.doNothing().when(hospitalRepo).delete(any(Hospital.class));
		Hospital hospital = hospitalService.getHospitalById(1);
		assertThat(hospital.getName()).isEqualTo("test");
	}
	@Test
	void getAllHospitals() throws Exception {
		Mockito.when(serviceRepo.findByName(any(String.class))).thenReturn(getServicesObject());
		Mockito.when(userRepo.findById(any(Long.class))).thenReturn(Optional.of(getAdminUserObject()));
		List<Hospital> l = new ArrayList<>();
		l.add(getHospitalObject());
		Mockito.when(hospitalRepo.findAll()).thenReturn(l);
		Mockito.when(hospitalRepo.findDistinctByNameContainingIgnoreCaseOrCityContainingIgnoreCaseOrServicesNameContainingIgnoreCaseOrderByAddedAtDesc(any(String.class),any(String.class), any(String.class))).thenReturn(l);
		List<Hospital> dto = hospitalService.getAllHospitals(null);
		List<Hospital> dto1 = hospitalService.getAllHospitals("n");
		assertThat(dto.size()).isEqualTo(1);
		assertThat(dto1.size()).isEqualTo(1);
	}
	
	private Service getServicesObject() {
		Service service = new Service();
		service.setAddedAt(new Date());
		service.setAddedBy(1);
		service.setId(1L);
		service.setModifiedAt(new Date());
		service.setModifiedBy(1);
		service.setName("test service");
		return service;
	}
	
	private Users getAdminUserObject() {
		Users user = new Users();
		user.setEmail("admin@gmail.com");
		user.setFirstName("test");
		user.setLastName("test");
		user.setId(1L);
		user.setRole("admin");
		return user;
	}
	
	private Users getUserUserObject() {
		Users user = new Users();
		user.setEmail("user@gmail.com");
		user.setFirstName("test");
		user.setLastName("user");
		user.setId(2L);
		user.setRole("user");
		return user;
	}
	
	private Slot getSlotObject() {
		Slot slot = new Slot();
		slot.setAddedBy(getAdminUserObject());
		slot.setAmount(10);
		slot.setDate(LocalDate.now());
		slot.setId(2L);
		slot.setStartTime("09:00");
		slot.setEndTime("10:00");
		slot.setService(getServicesObject());
		//slot.setHospital(getHospitalObject());
		slot.setStatus("AVAILABLE");
		return slot;
	}
	
	private Hospital getHospitalObject() {
		Hospital hospital = new Hospital();
		hospital.setAddedAt(new Date());
		hospital.setAddedBy(getAdminUserObject());
		hospital.setCity("test");
		hospital.setCountry("test");
		hospital.setName("test");
		hospital.setZipcode("test");
		hospital.setStreet("test");
		hospital.setState("test");
		hospital.setModifiedAt(new Date());
		hospital.setId(2L);
		List<Service> list = new ArrayList<>();
		list.add(getServicesObject());
		hospital.setServices(list);
		
		List<Slot> slots = new ArrayList<>();
		slots.add(getSlotObject());
		hospital.setSlots(slots);
		
		return hospital;
	}
	
	private HospitalModel formHospitalModel() {
		HospitalModel model = new HospitalModel();
		model.setCity("test");
		model.setCountry("test");
		model.setHospitalName("test");
		model.setState("test");
		model.setZipcode("test");
		model.setStreet("test");
		List<String> list = new ArrayList<>();
		list.add("test");
		model.setServiceList(list);
		
		SlotModel smodel = new SlotModel();
		smodel.setDate("2022-10-22");
		smodel.setAmount(10);
		smodel.setEndTime("10:00");
		smodel.setStartTime("11:00");
		smodel.setService("test");
		List<SlotModel> slt = new ArrayList<>();
		slt.add(smodel);
		model.setSlotList(slt);
		return model;
	}
	
	private HospitalUpdateModel formHospitalUpdateModel() {
		HospitalUpdateModel model = new HospitalUpdateModel();
		model.setCity("update");
		model.setCountry("update");
		model.setHospitalName("update");
		model.setState("update");
		model.setZipcode("update");
		model.setStreet("update");
		List<String> list = new ArrayList<>();
		list.add("test");
		model.setServiceList(list);
		return model;
	}
	
	public HospitalSlotsModel formHospitalSlotsModel() {
		HospitalSlotsModel model = new HospitalSlotsModel();
		SlotModel smodel = new SlotModel();
		smodel.setDate("2022-10-22");
		smodel.setAmount(10);
		smodel.setEndTime("10:00");
		smodel.setStartTime("11:00");
		smodel.setService("test");
		List<SlotModel> slt = new ArrayList<>();
		slt.add(smodel);
		model.setSlotList(slt);
		return model;
	}
}
