import { FormControl, Grid, Input, InputLabel, Snackbar } from '@mui/material';
import Button from '@mui/material/Button';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import { editServices } from '../../api-service/backendServices';
import add_service from '../../assets/add_service.svg';
export default function EditService({ editServiceModal, serviceId, serviceNameFromDb }) {
    const [serviceName, setServiceName] = React.useState(serviceNameFromDb);

    const [snackMessage, setSnackMessage] = React.useState('');
    const [openSnack, setOpenSnack] = React.useState(false);
    const handleSnackClose = () => {
        setOpenSnack(!openSnack);
    };
    function editService() {
        if (serviceName === "" || serviceName === undefined
        ) {
            setSnackMessage('Fields cannot be blank');
            setOpenSnack(true);
        } else {
            editServices(serviceId, serviceName).then(resp => {
                console.log(resp);
                if (resp.status === 500) {
                    setSnackMessage('Error occured while update service');
                    setOpenSnack(true);
                } else {
                    let data = resp.data;
                    console.log(data);
                    setSnackMessage('Service updated successfully');
                    setOpenSnack(true);
                    editServiceModal();
                }
            });
        }
    }
    const handleServiceNameChange = (e) => {
        setServiceName(e.target.value);
    };

    return (
        <React.Fragment>
            <Grid container >
                <Grid xs={12}>

                    <DialogContent>
                        <Grid container direction={'row'}>
                            <Grid md={6}>
                                <Image src={add_service} style={{ marginLeft: '20px', height: '200px' }} />
                            </Grid>
                            <Grid md={6}>
                                <br></br><br></br>
                                <FormControl required={true} variant="standard" style={{ textAlign: 'center' }}>
                                    <InputLabel htmlFor="standard-adornment-fname">Update Service Name</InputLabel>
                                    <Input
                                        id="standard-adornment-fname"
                                        type={'text'}
                                        value={serviceName}
                                        onChange={handleServiceNameChange}
                                    />
                                </FormControl>
                                <br></br><br></br>
                            </Grid>
                        </Grid>

                    </DialogContent>
                    <DialogActions align='center'>
                        <Button variant="contained" style={{ backgroundColor: "green" }} onClick={editService}>&nbsp;UPDATE</Button>
                    </DialogActions>

                </Grid>
            </Grid>
            <Snackbar
                style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
                autoHideDuration={3000}
                anchorOrigin={{
                    vertical: "center",
                    horizontal: "center"
                }}
                open={openSnack}
                onClose={handleSnackClose}
                message={snackMessage}
            />
        </React.Fragment>
    );
}