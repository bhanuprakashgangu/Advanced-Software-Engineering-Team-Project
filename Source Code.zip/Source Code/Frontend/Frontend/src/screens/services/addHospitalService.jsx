import { FormControl, Grid, Input, InputLabel, Snackbar } from '@mui/material';
import Button from '@mui/material/Button';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import { addService } from '../../api-service/backendServices';
import add_service from '../../assets/edit_service.svg';
export default function AddService({ addServiceModal }) {
    const [serviceName, setServiceName] = React.useState('');
    const [snackMessage, setSnackMessage] = React.useState('');
    const [openSnack, setOpenSnack] = React.useState(false);
    const handleSnackClose = () => {
        setOpenSnack(!openSnack);
    };

    const handleServiceNameChange = (e) => {
        setServiceName(e.target.value);
    };

    function addNewService() {
        if (serviceName === "" || serviceName === undefined
        ) {
            setSnackMessage('Fields cannot be blank');
            setOpenSnack(true);
        } else {
            addService(serviceName).then(resp => {
                console.log(resp);
                let data = resp.data;
                console.log(data);
                setSnackMessage('Service added successfully');
                setOpenSnack(true);
                addServiceModal();
            });
        }
    }
    return (
        <React.Fragment>
            <Grid container >
                <Grid xs={12}>
                    <DialogContent>
                        <Grid container direction={'row'}>
                            <Grid md={6}>
                                <Image src={add_service} style={{ marginLeft: '20px', height: '200px' }} />
                            </Grid>
                            <Grid md={6}>
                                <br></br> <br></br>
                                <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                                    <InputLabel htmlFor="standard-adornment-fname">Enter Service Name</InputLabel>
                                    <Input
                                        id="standard-adornment-fname"
                                        type={'text'}
                                        value={serviceName}
                                        onChange={handleServiceNameChange}
                                    />
                                </FormControl>
                                <br></br>
                            </Grid>
                        </Grid>

                    </DialogContent>
                    <DialogActions align='center'>
                        <Button variant="contained" style={{ backgroundColor: "green" }} onClick={addNewService}>&nbsp;Add</Button>
                    </DialogActions>
                </Grid>

            </Grid>
            <Snackbar
                style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
                autoHideDuration={3000}
                anchorOrigin={{
                    vertical: "center",
                    horizontal: "center"
                }}
                open={openSnack}
                onClose={handleSnackClose}
                message={snackMessage}
            />
        </React.Fragment>
    );
}