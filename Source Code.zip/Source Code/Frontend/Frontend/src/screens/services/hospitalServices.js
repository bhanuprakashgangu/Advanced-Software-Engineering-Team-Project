import { Grid, Snackbar } from '@mui/material';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import PropTypes from 'prop-types';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import { deleteServices, getAllServices } from '../../api-service/backendServices';
import add from '../../assets/add.png';
import deletes from '../../assets/delete.png';
import edit from '../../assets/edit.png';
import services from '../../assets/services.svg';
import Header from '../navbar/Navbar';
import AddService from './addHospitalService';
import EditService from './editHospitalService';
export default function HospitalService() {
  const [value, setValue] = React.useState(1);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [isAddServiceOpen, setIsAddServiceOpen] = React.useState(false);
  const [openSnack, setOpenSnack] = React.useState(false);
  const [isEditServiceOpen, setIsEditServiceOpen] = React.useState(false);

  const [eServiceId, seteServiceId] = React.useState('');
  const [eServiceName, seteServiceName] = React.useState('');


  const [snackMessage, setSnackMessage] = React.useState('');
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };
  const [serviceList, setServiceList] = React.useState([]);
  const loginHandler = (value) => {
    setIsLoggedIn(value);
  }



  React.useEffect(() => {
    getLoggedInStatus();
  }, [value]);

  const editService = (id, pos) => {
    seteServiceId(id);
    seteServiceName(serviceList[pos].name);
    toggleEditServiceModal();
  }

  const deleteService = (id) => {
    console.log(id);
    deleteServices(id).then(resp => {
      if (resp.status === 500) {
        setSnackMessage('Error occured during delete service');
        setOpenSnack(true);
      } else {
        console.log(resp);
        setSnackMessage('Service deleted successfully');
        setOpenSnack(true);
        getAllServices().then(resp => {
          console.log(resp);
          let data = resp.data;
          console.log(data);
          setServiceList(data);
        }).catch(error => {
          setOpenSnack(true);
          setSnackMessage(error.response.data.message);

          console.log("login user err " + error);
        });
      }

    }).catch(error => {
      setOpenSnack(true);
      setSnackMessage("Deletion failed: " + error.response.data.message);
      console.log("login user err " + error);
    })
  }

  React.useEffect(() => {
    getAllServices().then(resp => {
      console.log(resp);
      let data = resp.data;
      console.log(data);
      setServiceList(data);
    }).catch(error => {
      console.log("login user err " + error);
    });


  }, []);

  function getLoggedInStatus() {
    if (localStorage.getItem("name") !== "" && localStorage.getItem("name") !== undefined
      && localStorage.getItem("name") !== null) {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }
  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
      padding: theme.spacing(2),
      minWidth: '700px !important',
      height: '400px'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));
  const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;
    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}

          >
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  };


  BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };


  function toggleEditServiceModal() {
    setIsEditServiceOpen(!isEditServiceOpen);
    if (isEditServiceOpen === true) {
      getAllServices().then(resp => {
        console.log(resp);
        let data = resp.data;
        console.log(data);
        setServiceList(data);
      }).catch(error => {
        console.log("login user err " + error);
      });
    }
  }
  const columns = [
    { id: 'sno', label: 'S.NO', minWidth: 40 },
    { id: 'name', label: 'SERVICES', minWidth: 200 },
    { id: 'id', label: 'ACTION', minWidth: 100 },
  ];

  function toggleAddServiceModal() {
    setIsAddServiceOpen(!isAddServiceOpen);
    if (isAddServiceOpen === true) {
      getAllServices().then(resp => {
        console.log(resp);
        let data = resp.data;
        console.log(data);
        setServiceList(data);
      }).catch(error => {
        console.log("login user err " + error);
      });

    }
  }

  return (
    <React.Fragment>
      <Header loginHandler={loginHandler} />
      <br></br><br></br><br></br>
      <Image src={add} onClick={toggleAddServiceModal} style={{ float: 'right', height: '120px', marginRight: '3%', marginTop: '10px', cursor: 'pointer' }}></Image>
      <Grid container direction="row" style={{ padding: '10px' }}>
        <Grid item md={5}>
          <Image src={services} style={{ marginTop: '-30px', marginLeft: '50px', height: '450px' }} />
        </Grid>
        <Grid item md={7}>
          <TableContainer component={Paper} style={{ width: '700px', maxHeight: '400px' }}>
            <Table stickyHeader aria-label="customized table">
              <TableHead>
                <TableRow>
                  {
                    columns.map((column) => (
                      <TableCell
                        key={column.id}
                        align={column.align}
                        style={{ minWidth: column.minWidth, fontWeight: '400', backgroundColor: '#566573', color: 'white', fontFamily: 'fantasy' }}
                      >
                        {column.label}
                      </TableCell>
                    ))
                  }

                </TableRow>
              </TableHead>
              <TableBody >
                {serviceList.map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                      {columns.map((column) => {
                        const value = row[column.id];
                        return (
                          <TableCell key={column.id} align={column.align} style={{ padding: '8px' }}>

                            {(column.id === 'id') ? (
                              <>
                                <IconButton aria-label="edit" onClick={(e) => editService(value, index)} style={{ color: '#566573' }} size="large">

                                  <Image src={edit} style={{ float: 'right', height: '40px', cursor: 'pointer' }}></Image>
                                </IconButton>
                                <IconButton style={{ color: 'red' }} onClick={(e) => deleteService(value)} aria-label="delete" size="large">

                                  <Image src={deletes} style={{ float: 'right', height: '40px', cursor: 'pointer' }}></Image>
                                </IconButton>
                              </>
                            ) : (column.id === 'sno') ? (
                              index + 1
                            ) : value}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
      </Grid>

      <BootstrapDialog
        onClose={toggleAddServiceModal}
        aria-labelledby="customized-dialog-title"
        open={isAddServiceOpen}
      >
        <BootstrapDialogTitle id="customized-dialog-title" className="toolHeader" style={{ textAlign: 'center', backgroundColor: '#566573', color: 'white' }}>
          ADD SERVICE
        </BootstrapDialogTitle>

        <AddService addServiceModal={toggleAddServiceModal} />

      </BootstrapDialog>
      <BootstrapDialog
        onClose={toggleEditServiceModal}
        aria-labelledby="customized-dialog-title"
        open={isEditServiceOpen}
      >
        <BootstrapDialogTitle id="customized-dialog-title" className="toolHeader" style={{ textAlign: 'center', backgroundColor: '#566573', color: 'white' }}>
          EDIT SERVICE
        </BootstrapDialogTitle>

        <EditService editServiceModal={toggleEditServiceModal}
          serviceId={eServiceId}
          serviceNameFromDb={eServiceName} />


      </BootstrapDialog>
      <Snackbar
        style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />
    </React.Fragment>
  );
}