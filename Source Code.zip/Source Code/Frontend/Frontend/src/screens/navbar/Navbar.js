import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import { alpha, styled } from '@mui/material/styles';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import {
  NavLink
} from 'react-router-dom';
import image from '../../assets/logo.png';
import logout from '../../assets/logout.png';
import "./Navbar.css";

export default function Header({ loginHandler }) {

  const [isOpen, setIsOpen] = React.useState(false);
  const [selectValue, setSelectValue] = React.useState("");
  const [value, setValue] = React.useState(1);
  let datas = {
    label: ""
  }
  const [logButtonName, setlogButtonName] = React.useState(isUserSessionAlreadyExist());


  //This function is to validate user session exists or not
  function isUserSessionAlreadyExist() {
    return "LOGOUT";
  }

  function toggleModal() {
    //alert(selectValue);
    if (logButtonName === 'LOGOUT') {
      localStorage.removeItem("firstname");
      localStorage.removeItem("lastname");
      localStorage.removeItem("email");
      localStorage.removeItem("userId");
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      setlogButtonName("LOGIN");
      window.location.replace("/")
    }
  }

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };





  //alert(selectValue);
  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
      padding: theme.spacing(2),
      //width: '300px !important',
      overflowY: 'unset'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));

  const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginRight: theme.spacing(2),
    marginLeft: 0,
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing(3),
      width: 'auto',
    },
  }));

  const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  }));
  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
      border: '2px SOLID red',
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('md')]: {
        width: '20ch',
      },
    },
  }));
  const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;
    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  };

  BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };
  return (
    <Box sx={{ flexGrow: 1, display: "flex" }}>
      <AppBar position="fixed"  >
        <Toolbar className="toolBar" position="fixed" style={{ backgroundColor: '#566573', height: '75px', width: '100%', position: 'fixed', borderBottom: '0.1em solid #B1F4F1', padding: '0.5em' }}>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 1 }}
          >
            <img src={image} className="img" style={{ height: '60px' }} />
          </IconButton>
          <Typography variant="h4" component="div" style={{ color: '#ffffff', fontFamily: 'ui-monospace' }} >
            HOSPITAL BOOKING SYSTEM
          </Typography>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
          {
            (localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "") ? (
              <>
                <NavLink className="navbar-item" to="/" style={{ color: '#ffffff', textDecoration: 'none' }}>
                  <IconButton>

                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      fontSize: '19px',
                      color: '#ffffff',
                    }}>&nbsp;<span>HOSPITALS</span>
                    </div>
                  </IconButton>
                </NavLink>
              </>) : ""}
          {

            (localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "" && localStorage.getItem("role").trim() === "user") ? (
              <>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                <NavLink className="navbar-item" to="/bookings" style={{ color: '#ffffff', textDecoration: 'none' }}>
                  <IconButton>
                    &nbsp;&nbsp;
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      fontSize: '19px',
                      color: '#ffffff',
                    }}>&nbsp;
                    <span>APPOINTMENTS</span>
                    </div>
                  </IconButton>
                </NavLink>
              </>
            ) : ""
          }

          {
            (localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "" && localStorage.getItem("role").trim() === "admin") ? (
              <> &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                <NavLink className="navbar-item" to="/services" style={{ color: '#ffffff', textDecoration: 'none' }}>
                  <IconButton>
                    &nbsp;&nbsp;
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      fontSize: '19px',
                      color: '#ffffff',
                    }}>&nbsp;<span>SERVICE</span>
                    </div>
                  </IconButton>
                </NavLink>
              </>
            ) : ""
          }




          <div style={{ flex: '1' }}></div>
          &nbsp;&nbsp;&nbsp;
          {
            (localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "") ? (
              <div style={{ cursor: 'pointer', color: '#ffffff', fontSize: '19px' }}><span> Hi {localStorage.getItem("firstname")}&nbsp;{localStorage.getItem("lastname")}</span>&nbsp;&nbsp;</div>
            ) : ""
          }
          {
            (localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "") ? (

              <Image src={logout} onClick={toggleModal} style={{ float: 'right', height: '50px', cursor: 'pointer' }}></Image>


            ) : ""
          }

        </Toolbar>
      </AppBar>
    </Box>
  );
}