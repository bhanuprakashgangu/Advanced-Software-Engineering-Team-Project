import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Dashboard from "./home/dashboard";
import UserSlotBookings from "./hospital/UserSlotBookings";
import HospitalService from "./services/hospitalServices";

const Controller = () => {
  const baseUrl = "/api/v1/";
  return (
    <Router>
      <div className="main-container">
        <Route
          exact
          path={["/", "/home"]}
          render={(props) => <Dashboard {...props} baseUrl={baseUrl} />}
        />
        <Route
          exact
          path={["/services"]}
          render={(props) => <HospitalService {...props} baseUrl={baseUrl} />}
        />

        <Route
          exact
          path={["/bookings"]}
          render={(props) => <UserSlotBookings {...props} baseUrl={baseUrl} />}
        />

      </div>
    </Router>
  );
};

export default Controller;
