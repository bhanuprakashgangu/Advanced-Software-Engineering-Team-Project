import { Card, CardContent, FormControl, Grid, InputLabel, MenuItem, Select, Snackbar, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Typography from '@mui/material/Typography';
import * as React from 'react';
import { bookSlotForHospital } from '../../api-service/backendServices';
export default function BookSlot({ bookSlotModal, hospitalId, hospitalNameFromDb, streetFromDb,
  cityFromDb, stateFromDb, countryFromDb, zipFromDb, slotId, serviceName, slotDate, slotSTime,
  slotETime, slotAmount }) {
  const [payment, setPayment] = React.useState("");
  const [cardDetails, setCardDetails] = React.useState("");
  const [message, setMessage] = React.useState("");
  const [snackMessage, setSnackMessage] = React.useState('');
  const [openSnack, setOpenSnack] = React.useState(false);
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };

  const paymentChange = (event) => {
    setPayment(event.target.value);
  }
  const messageChange = (event) => {
    setMessage(event.target.value);
  }
  const cardDetailsChange = (event) => {
    setCardDetails(event.target.value);
  }
  const columns = [
    { id: 'sNo', label: 'S.NO', minWidth: 20 },
    { id: 'service', label: 'Service', minWidth: 100 },
    { id: 'date', label: 'Date', minWidth: 100 },
    { id: 'startTime', label: 'START TIME', minWidth: 100 },
    { id: 'endTime', label: 'END TIME', minWidth: 100 },
    { id: 'amount', label: 'AMOUNT($)', minWidth: 100 },
    { id: 'status', label: 'STATUS', minWidth: 100 },
    { id: 'action', label: 'ACTIONS', minWidth: 100 }
  ];

  function bookSlot() {

    if (message === null || message === "" || message === undefined) {
      setSnackMessage('Fields cannot be blank');
      setOpenSnack(true);
    } else {
      bookSlotForHospital(hospitalId, slotId, message, payment, cardDetails).then(respp => {
        console.log(respp);
        let datta = respp.data;
        console.log(datta);
        setSnackMessage('Your selected slot booked successfully, we will send an confirmation email to you shortly');
        setOpenSnack(true);
        bookSlotModal();
      });
    }
  }

  return (
    <React.Fragment>
      <>
        <DialogContent >
          <Grid container >
            <Grid md={12} >
              <Grid md={9} ><br></br>
                <Card sx={{ minWidth: '250px' }} style={{backgroundColor:'coral', color:'white'}}>
                  <CardContent>
                    <Typography gutterBottom variant="h6" component="div" style={{ fontSize: 14, fontWeight: '700' }}>
                      {hospitalNameFromDb.toUpperCase()}
                    </Typography>
                    <Typography variant="body2" color="white">
                      {streetFromDb},
                    </Typography>
                    <Typography variant="body2" color="white" >
                      {cityFromDb},
                    </Typography>
                    <Typography variant="body2" color="white" >
                      {stateFromDb},
                    </Typography>
                    <Typography variant="body2" color="white" >
                      {countryFromDb}-{zipFromDb}
                    </Typography>
                    <br></br>
                    <table >
                      <tr>
                        <th style={{ border: '1px solid black', textAlign: 'center' }}>Service</th>
                        <th style={{ border: '1px solid black', textAlign: 'center' }}>Date</th>
                        <th style={{ border: '1px solid black', textAlign: 'center' }}>Start Time</th>
                        <th style={{ border: '1px solid black', textAlign: 'center' }}>End Time</th>
                        <th style={{ border: '1px solid black', textAlign: 'center' }}>Amount($)</th>
                      </tr>
                      <tr key={1}>
                        <td style={{ border: '1px solid black', textAlign: 'center', whiteSpace: 'nowrap' }}>{serviceName}</td>
                        <td style={{ border: '1px solid black', textAlign: 'center', whiteSpace: 'nowrap' }}>{slotDate}</td>
                        <td style={{ border: '1px solid black', textAlign: 'center', whiteSpace: 'nowrap' }}>{slotSTime}</td>
                        <td style={{ border: '1px solid black', textAlign: 'center', whiteSpace: 'nowrap' }}>{slotETime}</td>
                        <td style={{ border: '1px solid black', textAlign: 'center', whiteSpace: 'nowrap' }}>{slotAmount}</td>
                      </tr>

                    </table>

                    <br></br>
                    <FormControl required={true} fullWidth sx={{ m: 1 }} variant="outlined" style={{ textAlign: 'center'}}>
                      <TextField
                        label="Message"
                        multiline
                        rows={4}
                        id="standard-adornment-fname"
                        type={'text'}
                        value={message}
                        InputProps={{
                          style: { color: "white", borderColor:'white' }
                          }}
                        onChange={messageChange}
                      />
                    </FormControl>

                    {parseInt(slotAmount) > 0 ? (
                      <>
                        <br></br><br></br>
                        <FormControl fullWidth required={true} sx={{ m: 1 }} variant="outlined" >
                          <InputLabel id="demo-simple-select-label">PAYMENT VIA</InputLabel>
                          <Select
                            style={{ height: '45px', color:'white' }}
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={payment}
                            label="PAYMENT VIA"
                            onChange={paymentChange}
                          >
                            <MenuItem value={"paypal"}>PAYPAL</MenuItem>
                            <MenuItem value={"bank_card"}>BANK ACCOUNT</MenuItem>
                            <MenuItem value={"e-wallet"}>E-WALLET</MenuItem>
                          </Select>
                        </FormControl>
                        <br></br>
                        <FormControl required={true} fullWidth sx={{ m: 1 }} variant="outlined" style={{ textAlign: 'center' }}>
                          <TextField
                            label="Account number / paypal id / E-Wallet ID"
                            size="small"
                            id="standard-adornment-fname"
                            type={'text'}
                            value={cardDetails}
                            onChange={cardDetailsChange}
                            InputProps={{
                              style: { color: "white" }
                              }}
                          />
                        </FormControl><br></br>
                      </>
                    ) : ""}
                  </CardContent>
                </Card>


              </Grid>
              <Grid md={3} ></Grid>



            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions align='center'>
          {parseInt(slotAmount) > 0 ? (
            <Button variant="contained" style={{ backgroundColor: "green" }} onClick={() => bookSlot()}>&nbsp;PAY & BOOK</Button>
          ) : (
            <Button variant="contained" style={{ backgroundColor: "green" }} onClick={() => bookSlot()}>&nbsp;BOOK</Button>
          )}
          <Button variant="contained" style={{ backgroundColor: "orange" }} onClick={bookSlotModal}>&nbsp;CLOSE</Button>
          {/* <Typography>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dont have an account? <Button color="primary" onClick={clickSignUp}>Sign up</Button></Typography> */}
        </DialogActions>
      </>
      <Snackbar
        style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />
    </React.Fragment>
  );
}