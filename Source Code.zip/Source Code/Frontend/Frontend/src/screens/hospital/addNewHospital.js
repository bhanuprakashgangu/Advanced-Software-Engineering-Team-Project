import holidays from '@date/holidays-us';
import { FormControl, Grid, InputLabel, ListItemText, MenuItem, OutlinedInput, Select, Snackbar, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import moment from 'moment';
import * as React from 'react';
import { addHospital, getAllServices } from '../../api-service/backendServices';
import DayWiseSlots from '../slot/DayWiseSlots';
import SpecificSlot from '../slot/ParticularDaySlot';
import { Image } from 'react-bootstrap';
import hospital from '../../assets/hospital.svg';
export default function AddHospital({ addHospitalModal }) {
  const [hospitalName, setHospitalName] = React.useState('');
  const [street, setStreet] = React.useState('');
  const [city, setCity] = React.useState('');
  const [zip, setZip] = React.useState('');
  const [state, setState] = React.useState('');
  const [country, setCountry] = React.useState('');
  const [specificDaySlots, setSpecificSlots] = React.useState([]);
  const [finalSlots, setFinalSlots] = React.useState([]);
  const [dayWiseSlots, setDailySlots] = React.useState([]);
  const [selectValue, setSelectValue] = React.useState([]);
  const [services, setServices] = React.useState([]);
  const [skipPublicHolidays, setSkipPublicHolidays] = React.useState(true);
  const [snackMessage, setSnackMessage] = React.useState('');
  const [openSnack, setOpenSnack] = React.useState(false);
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };
  const handleHospitalDescChange = (e) => {
    setStreet(e.target.value);
  };
  const handleHospitalNameChange = (e) => {
    setHospitalName(e.target.value);
  };
  const handleHospitalGenderChange = (e) => {
    setCity(e.target.value);
  };
  const handleSkipPublicHolidayChange = (e) => {
    setSkipPublicHolidays(e.target.checked);
  };
  const handleHospitalCastChange = (e) => {
    setZip(e.target.value);
  };

  const handleHospitalDurationChange = (e) => {
    setState(e.target.value);
  };

  const handleHospitalPosterChange = (e) => {
    setCountry(e.target.value);
  };

  React.useEffect(() => {
    getAllServices().then(resp => {
      console.log(resp);
      let data = resp.data;
      console.log(data);
      setServices(data);
    }).catch(error => {
      console.log("login user err " + error);
    });


  }, []);

  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    setSelectValue(typeof value === 'string' ? value.split(',') : value);
  };
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  function getDayNumberByDays(day) {
    var start = moment(new Date()), // Sept. 1st
      end = moment(new Date()).add(1, 'y');

    var result = [];
    var current = start.clone();

    while (current.day(7 + day).isBefore(end)) {
      console.log(holidays.isHoliday(current.clone().toDate()) + "--" + skipPublicHolidays);
      if (skipPublicHolidays && !holidays.isHoliday(current.clone().toDate())) {
        result.push(current.clone().toDate());
      } else if (!skipPublicHolidays) {
        result.push(current.clone().toDate());
      }

    }
    return result;
  }

  function addNewHospital() {
    dayWiseSlots.length > 0 && dayWiseSlots.forEach(eachItem => {
      if (eachItem !== null && eachItem !== "" && eachItem !== undefined && eachItem.timeRange !== null && eachItem.timeRange !== "" && eachItem.timeRange !== undefined) {
        if (eachItem.timeRange.startTime !== null && eachItem.timeRange.startTime !== "" && eachItem.timeRange.startTime !== undefined && moment(eachItem.timeRange.startTime).format('HH:mm') !== "Invalid date") {
          eachItem.timeRange.startTime = moment(eachItem.timeRange.startTime).format('HH:mm');
        }
        if (eachItem.timeRange.endTime !== null && eachItem.timeRange.endTime !== "" && eachItem.timeRange.endTime !== undefined && moment(eachItem.timeRange.endTime).format('HH:mm') !== "Invalid date") {
          eachItem.timeRange.endTime = moment(eachItem.timeRange.endTime).format('HH:mm');
        }
      }

    });

    specificDaySlots.length > 0 && specificDaySlots.forEach(eachItem => {
      if (eachItem !== null && eachItem !== "" && eachItem !== undefined && eachItem.timeRange !== null && eachItem.timeRange !== "" && eachItem.timeRange !== undefined) {
        if (eachItem.timeRange.startTime !== null && eachItem.timeRange.startTime !== "" && eachItem.timeRange.startTime !== undefined && moment(eachItem.timeRange.startTime).format('HH:mm') !== "Invalid date") {
          eachItem.timeRange.startTime = moment(eachItem.timeRange.startTime).format('HH:mm');
        }
        if (eachItem.timeRange.endTime !== null && eachItem.timeRange.endTime !== "" && eachItem.timeRange.endTime !== undefined && moment(eachItem.timeRange.endTime).format('HH:mm') !== "Invalid date") {
          eachItem.timeRange.endTime = moment(eachItem.timeRange.endTime).format('HH:mm');
        }
      }
    });
    console.log(dayWiseSlots);
    let totalSlotList = [];
    dayWiseSlots.length > 0 && dayWiseSlots.forEach(eachItem => {
      if (eachItem !== null && eachItem !== "" && eachItem !== undefined && eachItem.day !== null && eachItem.day !== "" && eachItem.day !== undefined &&
        !isNaN(eachItem.amount) && eachItem.service !== null && eachItem.service !== "" && eachItem.service !== undefined && eachItem.timeRange !== null && eachItem.timeRange !== "" && eachItem.timeRange !== undefined) {
        let dateList = [];
        if (eachItem.day === "SUNDAY") {
          dateList = getDayNumberByDays(1);
        } else if (eachItem.day === "MONDAY") {
          dateList = getDayNumberByDays(2);
        } else if (eachItem.day === "TUESDAY") {
          dateList = getDayNumberByDays(3);
        } else if (eachItem.day === "WEDNESDAY") {
          dateList = getDayNumberByDays(4);
        } else if (eachItem.day === "THURSDAY") {
          dateList = getDayNumberByDays(5);
        } else if (eachItem.day === "FRIDAY") {
          dateList = getDayNumberByDays(6);
        } else {
          dateList = getDayNumberByDays(0);
        }

        dateList.forEach(eachDate => {
          totalSlotList.push({
            date: eachDate,
            startTime: eachItem.timeRange.startTime,
            endTime: eachItem.timeRange.endTime,
            service: eachItem.service,
            amount: eachItem.amount
          });
        });
      }
      console.log(totalSlotList);
    });

    specificDaySlots.length > 0 && specificDaySlots.forEach(eachItem => {
      if (eachItem !== null && eachItem !== "" && eachItem !== undefined && eachItem.date !== null && eachItem.date !== "" && eachItem.date !== undefined &&
        eachItem.service !== null && eachItem.service !== "" && eachItem.service !== undefined
        && !isNaN(eachItem.amount) && eachItem.timeRange !== null && eachItem.timeRange !== "" && eachItem.timeRange !== undefined) {
        totalSlotList.push({
          date: eachItem.date,
          startTime: eachItem.timeRange.startTime,
          endTime: eachItem.timeRange.endTime,
          service: eachItem.service,
          amount: eachItem.amount
        });
      }
    });
    console.log(totalSlotList);
    totalSlotList.sort(function (a, b) {
      return new Date(a.date) - new Date(b.date)
    })


    totalSlotList.length > 0 && totalSlotList.forEach(eachItem => {
      if (eachItem !== null && eachItem !== "" && eachItem !== undefined && eachItem.date !== null && eachItem.date !== "" && eachItem.date !== undefined) {
        if (eachItem.date !== null && eachItem.date !== "" && eachItem.date !== undefined && moment(eachItem.date).format("YYYY-MM-DD") !== "Invalid date") {
          eachItem.date = moment(eachItem.date).format("YYYY-MM-DD");
        }
      }
    });
    let arr = [];
    totalSlotList.length > 0 && totalSlotList.forEach(eachItem => {
      arr.push(eachItem);
    });
    setFinalSlots(arr);
    console.log(totalSlotList);

    if (hospitalName === "" || hospitalName === undefined || street === "" || street === undefined ||
      zip === "" || zip === undefined || city === "" || city === undefined ||
      state === "" || state === undefined || country === "" || country === undefined
    ) {
      setSnackMessage('Fields cannot be blank');
      setOpenSnack(true);
    } else {
      addHospital(hospitalName, street, zip, city, state, country, totalSlotList, selectValue).then(resp => {
        console.log(resp);
        let data = resp.data;
        console.log(data);
        setSnackMessage('Hospital added successfully');
        setOpenSnack(true);
        addHospitalModal();
      });
    }
  }
  return (
    <React.Fragment>
      <DialogContent>
        <Grid container >
          <Grid item xs={5}>
            <Image src={hospital} style={{ marginLeft: '20px' }} />

          </Grid>
          <Grid item xs={1}></Grid>
          <Grid item xs={6}>

            <br></br><br></br>
            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                label="Enter Hospital Name"
                size="small"
                type={'text'}
                value={hospitalName}
                onChange={handleHospitalNameChange}
              />
            </FormControl>
            <br></br><br></br>
            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                label="Street"
                size="small"
                type={'text'}
                value={street}
                onChange={handleHospitalDescChange}
              />
            </FormControl>

            <br></br><br></br>

            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                size="small"
                label="City"
                type={'text'}
                value={city}
                onChange={handleHospitalGenderChange}
              />
            </FormControl>
            <br></br><br></br>

            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                size="small"
                label="Zip code"
                type={'text'}
                value={zip}
                onChange={handleHospitalCastChange}
              />
            </FormControl>
            <br></br><br></br>
            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                label="State"
                size="small"
                type={'text'}
                value={state}
                onChange={handleHospitalDurationChange}
              />
            </FormControl>
            <br></br><br></br>

            <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
              <TextField
                id="standard-adornment-fname"
                label="Country"
                size="small"
                type={'text'}
                value={country}
                onChange={handleHospitalPosterChange}
              />
            </FormControl>
            <br></br><br></br>

            <FormControl fullWidth >
              <InputLabel id="demo-multiple-checkbox-label"  >Select services</InputLabel>
              <Select
                labelId="demo-multiple-checkbox-label"
                id="demo-multiple-checkbox"
                multiple
                size="small"
                value={selectValue}
                onChange={handleChange}
                input={<OutlinedInput label="Select services" />}
                renderValue={(selected) => selected.join(', ')}
                MenuProps={MenuProps}
              >
                {services.map((eachItem) => (
                  <MenuItem key={eachItem.name} value={eachItem.name}>
                    <Checkbox checked={selectValue.indexOf(eachItem.name) > -1} />
                    <ListItemText primary={eachItem.name} />
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

          </Grid>

          <br></br><br></br>
          {
            <Grid item xs={12}>
              <DayWiseSlots services={selectValue} setPractice={setDailySlots} practice={dayWiseSlots} skipPublicHolidays={skipPublicHolidays} handleSkipPublicHolidayChange={handleSkipPublicHolidayChange} />
            </Grid>
          }


          {
            <Grid item xs={12}>
              <SpecificSlot services={selectValue} setPractice={setSpecificSlots} practice={specificDaySlots} />
            </Grid>
          }








        </Grid>
      </DialogContent>
      <DialogActions align='center'>
        <Button variant="contained" style={{ backgroundColor: "#566573" }} onClick={addNewHospital}>&nbsp;SAVE HOSPITAL</Button>
    </DialogActions>
      <Snackbar
        style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />
    </React.Fragment>
  );
}