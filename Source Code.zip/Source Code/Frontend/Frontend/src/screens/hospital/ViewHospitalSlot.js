import BookmarkAddedIcon from '@mui/icons-material/BookmarkAdded';
import ManageSearchIcon from '@mui/icons-material/ManageSearch';
import { Card, Dialog, DialogTitle, Grid, IconButton, Snackbar, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import { styled } from '@mui/material/styles';
import PropTypes from 'prop-types';
import * as React from 'react';
import { deleteSlotsToHospital, getAllSlotsBetweenDates, getHospitalById } from '../../api-service/backendServices';
//import { addTheater } from '../util/apiCalls';
import { DesktopDatePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import moment from 'moment';
import { Image, Tooltip } from 'react-bootstrap';
import hospital from '../../assets/appointment.svg';
import BookSlot from './HospitalBookSlot';


export default function ViewSlot({ viewSlotModal, hospitalId }) {
  const [isAddShowOpen, setIsAddShowOpen] = React.useState(false);
  const [isBookHospitalOpen, setIsBookHospitalOpen] = React.useState(false);
  const [hospitalData, setHospitalData] = React.useState('');
  const [isBookSlotOpen, setIsBookSlotOpen] = React.useState(false);
  const [sdate, setSDate] = React.useState('');
  const [edate, setEDate] = React.useState('');
  const [selectValue, setSelectValue] = React.useState([]);
  const [skipPublicHolidays, setSkipPublicHolidays] = React.useState(true);
  const [eHospitalId, seteHospitalId] = React.useState('');
  const [eHospitalName, seteHospitalName] = React.useState('');
  const [eStreet, seteStreet] = React.useState('');
  const [eCity, seteCity] = React.useState('');
  const [eState, seteState] = React.useState('');
  const [eCountry, seteCountry] = React.useState('');
  const [eZip, setezip] = React.useState('');

  const [slotId, setSlotId] = React.useState('');
  const [serviceName, setServiceName] = React.useState('');
  const [slotDate, setSlotDate] = React.useState('');
  const [slotSTime, setSlotSTime] = React.useState('');
  const [slotETime, setSlotETime] = React.useState('');
  const [slotAmount, setSlotAmount] = React.useState('');


  const [slotData, setSlotData] = React.useState([]);
  const [snackMessage, setSnackMessage] = React.useState('');
  const [openSnack, setOpenSnack] = React.useState(false);
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };


  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleSkipPublicHolidayChange = (e) => {
    setSkipPublicHolidays(e.target.checked);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  function deleteSlot(id) {
    deleteSlotsToHospital(hospitalId, id).then(respp => {
      console.log(respp);
      let datta = respp.data;
      console.log(datta);
      getHospitalById(hospitalId).then(resp => {

        console.log(resp);
        resp.json().then(data => {
          console.log(data);
          setHospitalData(data);
          setSlotData(data.slots);
          let serviceNames = []
          data.services.forEach(each => {
            serviceNames.push(each.name);
          })
          setSelectValue(serviceNames);
        });
      }).catch(error => {
        console.log("login user err " + error);
      })
      setSnackMessage('Slots deleted successfully');
      setOpenSnack(true);
    });
  }

  const columns = [
    { id: 'sNo', label: 'S.NO', minWidth: 20 },
    { id: 'service', label: 'Service', minWidth: 150 },
    { id: 'date', label: 'Date', minWidth: 150 },
    { id: 'startTime', label: 'START TIME', minWidth: 100 },
    { id: 'endTime', label: 'END TIME', minWidth: 100 },
    { id: 'amount', label: 'AMOUNT($)', minWidth: 100 },
    { id: 'status', label: 'STATUS', minWidth: 120 },
    { id: 'action', label: 'ACTIONS', minWidth: 120 }
  ];

  React.useEffect(() => {
    getHospitalById(hospitalId).then(resp => {

      console.log(resp);
      resp.json().then(data => {
        console.log(data);
        seteHospitalName(data.name);
        seteStreet(data.street);
        seteCity(data.city);
        seteState(data.state);
        seteCountry(data.country);
        setezip(data.zipcode);
      });
    }).catch(error => {
      console.log("login user err " + error);
    })


  }, [])
  let no = 1;

  function searchSlots() {
    if (sdate === "" || sdate === undefined || edate === "" || edate === undefined) {
      setSnackMessage('Fields cannot be blank');
      setOpenSnack(true);
    } else {
      getAllSlotsBetweenDates(hospitalId, moment(sdate).format("YYYY-MM-DD"), moment(edate).format("YYYY-MM-DD")).then(respp => {
        console.log(respp);
        let datta = respp.data;
        console.log(datta);
        setSlotData(datta);
      });
    }
  }

  function bookSlot(id) {
    setSlotId(id);
    slotData.forEach(each => {
      if (each.id === id) {
        setServiceName(each.service.name);
        setSlotDate(each.date);
        setSlotSTime(each.startTime);
        setSlotETime(each.endTime);
        setSlotAmount(each.amount);
      }
    })
    toggleBookSlotModal();
  }


  const handleEDateChange = (e) => {
    setEDate(e)
  }

  const handleSDateChange = (e) => {
    setSDate(e)
  }

  const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
      padding: theme.spacing(2),
      minWidth: '1000px !important',
      height: '700px'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));
  const BootstrapDialogTitle = (props) => {
    const { children, onClose, ...other } = props;
    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  };

  function toggleBookSlotModal() {
    setIsBookSlotOpen(!isBookSlotOpen);
    if (isBookSlotOpen === true) {
      getAllSlotsBetweenDates(hospitalId, moment(sdate).format("YYYY-MM-DD"), moment(edate).format("YYYY-MM-DD")).then(respp => {
        console.log(respp);
        let datta = respp.data;
        console.log(datta);
        setSlotData(datta);
      });
    }
  }
  BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };

  return (
    <React.Fragment>
      <>
        <DialogContent>
          <Grid container direction={"row"} >
            <Grid md={3} >
              <Image src={hospital} style={{ marginLeft: '20px', marginTop: '80px' }} />


            </Grid>
            <Grid md={1} ></Grid>
            <Grid md={8} ><br></br>

              <LocalizationProvider fullWidth dateAdapter={AdapterDateFns} style={{ maxWidth: '20% !important' }}>
                <DesktopDatePicker
                  label="Start date"
                  fullWidth
                  value={sdate}
                  disablePast="true"
                  onChange={handleSDateChange}
                  renderInput={(params) => <TextField {...params} />}
                /></LocalizationProvider> &nbsp;&nbsp;&nbsp;

              <LocalizationProvider fullWidth dateAdapter={AdapterDateFns} style={{ maxWidth: '20% !important' }}>
                <DesktopDatePicker
                  label="End date"
                  fullWidth
                  value={edate}
                  disablePast="true"
                  onChange={handleEDateChange}
                  renderInput={(params) => <TextField {...params} />}
                /></LocalizationProvider> &nbsp;&nbsp;&nbsp;


              <Button variant="contained" style={{ backgroundColor: "green", padding: '15px' }}
                size="large" onClick={searchSlots}><ManageSearchIcon />&nbsp;SEARCH</Button>

              <br></br><br></br>
              {slotData.length > 0 ? (
                <Card sx={{ width: '100%', backgroundColor: 'aliceblue', color: '#566573', padding: '20px' }}>

                  <TableContainer sx={{ minHeight: 277, maxHeight: 300, width: '100%' }}>
                    <Table stickyHeader aria-label="sticky table" class="min-w-max w-full table-auto ">
                      <TableHead style={{ backgroundColor: '#566573', color: 'white', padding: '10px' }}>
                        <TableRow class="bg-gray-900 text-gray-500 uppercase leading-normal">
                          {columns.map((column) => (
                            <TableCell
                              key={column.id}
                              align={column.align}
                              style={{ minWidth: column.minWidth, backgroundColor: '#566573', color: 'white', padding: '5px' }}
                              class="py-3 px-6 text-center"
                            >
                              {column.label}
                            </TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody class="text-gray-200 bg-gray-700 text-sm font-light ">
                        {slotData
                          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                          .map((row, ind) => {
                            return (
                              <TableRow role="checkbox" hover={true} tabIndex={-1} key={ind} style={{ textAlign: 'center' }}>
                                {columns.map((column) => {
                                  const id = row["id"];
                                  const value = row[column.id];
                                  return (
                                    <TableCell key={column.id} align={column.align} class="py-3 px-6 text-left whitespace-nowrap">
                                      {(column.id === 'action') ? (
                                        <><Tooltip title="Delete slot">
                                            <Button style={{ color: 'white', backgroundColor: "#566573", alignContent: 'center' }}
                                              onClick={() => bookSlot(id)}
                                              aria-label="delete" >
                                              <BookmarkAddedIcon sx={{ fontSize: '20px' }} />BOOK
                                            </Button>
                                          </Tooltip>
                                        </>
                                      ) :
                                        (column.id === 'sNo') ? (
                                          ind + 1 + (page * 10)
                                        ) : (column.id === 'status') ? (
                                          <Chip label={value} style={{ backgroundColor: 'orange', color: 'white' }}></Chip>
                                        ) : (column.id === 'service') ? (
                                          <span className="bg-green-400 text-black py-1 px-3 rounded-full text-xs">{value.name}</span>
                                        ) : value}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            );
                          })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  <TablePagination
                    rowsPerPageOptions={[5, 10, 25]}
                    component="div"
                    count={slotData.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    class="bg-gray-900 text-white uppercase leading-normal"
                  />

                </Card>
              ) : ""}
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions align='center'>


          <Button variant="contained" style={{ backgroundColor: "orange" }} onClick={viewSlotModal}>&nbsp;Close</Button>
        </DialogActions>
      </>





      <BootstrapDialog
        onClose={toggleBookSlotModal}
        aria-labelledby="customized-dialog-title"
        open={isBookSlotOpen}
      >
        <BootstrapDialogTitle id="customized-dialog-title" className="toolHeader" style={{ textAlign: 'center', backgroundColor: '#566573', color: 'white' }}>
          BOOK SLOT
        </BootstrapDialogTitle>

        <BookSlot bookSlotModal={toggleBookSlotModal}
          hospitalId={hospitalId}
          hospitalNameFromDb={eHospitalName}
          streetFromDb={eStreet}
          cityFromDb={eCity}
          stateFromDb={eState}
          countryFromDb={eCountry}
          zipFromDb={eZip}
          slotId={slotId}
          serviceName={serviceName}
          slotDate={slotDate}
          slotSTime={slotSTime}
          slotETime={slotETime}
          slotAmount={slotAmount}
        />


      </BootstrapDialog>

      <Snackbar
        style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />
    </React.Fragment>
  );
}