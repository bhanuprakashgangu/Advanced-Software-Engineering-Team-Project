import CancelIcon from '@mui/icons-material/Cancel';
import { Button, Card, Chip, Grid, Snackbar, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Tooltip } from '@mui/material';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import { cancelSlotForHospital, getAllBookings } from '../../api-service/backendServices';
import hospital from '../../assets/bookings.svg';
import Header from '../navbar/Navbar';
export default function UserSlotBookings() {
    if (localStorage.getItem('email') === "" || localStorage.getItem('email') === null) {
        window.location.replace("/");
    }
    const [isLoggedIn, setIsLoggedIn] = React.useState(false);
    const [bookingList, setBookingList] = React.useState([]);
    const [value, setValue] = React.useState(1);
    const [snackMessage, setSnackMessage] = React.useState('');
    const [openSnack, setOpenSnack] = React.useState(false);
    const handleSnackClose = () => {
        setOpenSnack(!openSnack);
    };

    React.useEffect(() => {
        getAllBookings().then(resp => {
            console.log(resp);
            resp.json().then(data => {
                console.log(data);
                setBookingList(data);
            });
        }).catch(error => {
            console.log("login user err " + error);
        })


    }, [])
    const loginHandler = (value) => {
        setIsLoggedIn(value);
    }
    function getLoggedInStatus() {
        if (localStorage.getItem("email") !== "" && localStorage.getItem("email") !== undefined
            && localStorage.getItem("email") !== null) {
            setIsLoggedIn(true);
        } else {
            setIsLoggedIn(false);
        }
    }
    React.useEffect(() => {
        getLoggedInStatus();

    }, [value]);

    function deleteBooking(id) {
        cancelSlotForHospital(id).then(respp => {
            console.log(respp);
            let datta = respp.data;
            console.log(datta);
            getAllBookings().then(resp => {
                console.log(resp);
                resp.json().then(data => {
                    console.log(data);
                    setBookingList(data);
                });
            }).catch(error => {
                console.log("login user err " + error);
            })
            setSnackMessage('Bookings cancelled successfully');
            setOpenSnack(true);
        });
    }

    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    const columns = [
        { id: 'sNo', label: 'S.NO', minWidth: 10 },
        { id: 'hospitalName', label: 'Hospital Name', minWidth: 160 },
        { id: 'serviceName', label: 'Service', minWidth: 130 },
        { id: 'date', label: 'Date', minWidth: 130 },
        { id: 'startTime', label: 'START TIME', minWidth: 120 },
        { id: 'endTime', label: 'END TIME', minWidth: 120 },
        { id: 'amount', label: 'AMOUNT($)', minWidth: 100 },
        { id: 'status', label: 'STATUS', minWidth: 150 },
        { id: 'action', label: 'ACTIONS', minWidth: 150 }
    ];


    return (
        <React.Fragment>
            <Header loginHandler={loginHandler} />
            <br></br><br></br><br></br><br></br><br></br>

            <Grid container style={{ padding: '20px' }}>
                <Grid md={3} >
                    <Image src={hospital} ></Image>

                </Grid>

                <Grid md={9} ><br></br>
                    <Card sx={{ minWidth: '250px', backgroundColor: 'white', color: '#566573', padding: '20px' }}>

                        <TableContainer sx={{ minHeight: 277, maxHeight: 300 }}>
                            <Table stickyHeader aria-label="sticky table" class="min-w-max w-full table-auto ">
                                <TableHead>
                                    <TableRow class="bg-gray-900 text-gray-500 uppercase leading-normal">
                                        {columns.map((column) => (
                                            <TableCell
                                                key={column.id}
                                                align={column.align}
                                                style={{ minWidth: column.minWidth, backgroundColor: '#566573', padding: '5px', color: 'white' }}
                                                class="py-3 px-6 text-center"
                                            >
                                                {column.label}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody class="text-gray-200 bg-gray-700 text-sm font-light ">
                                    {bookingList
                                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        .map((row, ind) => {
                                            return (
                                                <TableRow role="checkbox" hover={true} tabIndex={-1} key={ind} style={{ textAlign: 'center' }}>
                                                    {columns.map((column) => {
                                                        const id = row["slotId"];
                                                        const value = row[column.id];
                                                        return (
                                                            <TableCell key={column.id} align={column.align} class="py-3 px-6 text-left whitespace-nowrap">
                                                                {(column.id === 'action') ? (
                                                                    <>

                                                                        <Tooltip title="Cancel slot">
                                                                            <Button style={{ color: 'white', backgroundColor: "#566573", alignContent: 'center' }}
                                                                                onClick={() => deleteBooking(id)}
                                                                                aria-label="delete" >
                                                                                <CancelIcon sx={{ fontSize: '20px' }} />&nbsp;CANCEL
                                                                            </Button>
                                                                        </Tooltip>
                                                                    </>
                                                                ) :
                                                                    (column.id === 'sNo') ? (
                                                                        ind + 1 + (page * 10)
                                                                    ) : (column.id === 'status') ? (
                                                                        value === "CANCELLED" ? (
                                                                            <Chip label={value} style={{ backgroundColor: 'orange', color: 'white' }}></Chip>
                                                                        ) : (
                                                                            <Chip label={value} style={{ backgroundColor: 'green', color: 'white' }}></Chip>
                                                                        )

                                                                    ) : (column.id === 'service') ? (
                                                                        <span className="bg-green-400 text-black py-1 px-3 rounded-full text-xs">{value.name}</span>
                                                                    ) : value}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                            );
                                        })}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <TablePagination
                            rowsPerPageOptions={[5, 10, 25]}
                            component="div"
                            count={bookingList.length}
                            rowsPerPage={rowsPerPage}
                            page={page}
                            onPageChange={handleChangePage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                            class="bg-gray-900 text-white uppercase leading-normal"
                        />

                    </Card>
                </Grid>
            </Grid>
            <Snackbar
                style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
                autoHideDuration={3000}
                anchorOrigin={{
                    vertical: "center",
                    horizontal: "center"
                }}
                open={openSnack}
                onClose={handleSnackClose}
                message={snackMessage}
            />
        </React.Fragment>
    );
}