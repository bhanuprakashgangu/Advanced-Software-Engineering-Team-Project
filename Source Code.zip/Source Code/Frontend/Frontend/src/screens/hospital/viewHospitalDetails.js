import DeleteIcon from '@mui/icons-material/Delete';
import { Card, Grid, Snackbar, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow } from '@mui/material';
import Button from '@mui/material/Button';
import Chip from '@mui/material/Chip';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import * as React from 'react';
import { deleteSlotsToHospital, getHospitalById, saveSlotsToHospital } from '../../api-service/backendServices';
import holidays from '@date/holidays-us';
import moment from 'moment';
import { Tooltip } from 'react-bootstrap';
import DailySlot from '../slot/DayWiseSlots';
import SpecificSlot from '../slot/ParticularDaySlot';


export default function ViewHospital({ viewHospitalModal, hospitalId }) {
  const [hospitalData, setHospitalData] = React.useState('');

  const [selectValue, setSelectValue] = React.useState([]);
  const [skipPublicHolidays, setSkipPublicHolidays] = React.useState(true);
  const [specificSlots, setSpecificSlots] = React.useState([]);
  const [finalSlots, setFinalSlots] = React.useState([]);
  const [dailySlots, setDailySlots] = React.useState([]);
  const [slotData, setSlotData] = React.useState([]);
  const [snackMessage, setSnackMessage] = React.useState('');
  const [openSnack, setOpenSnack] = React.useState(false);
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };


  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleSkipPublicHolidayChange = (e) => {
    setSkipPublicHolidays(e.target.checked);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  function deleteSlot(id) {
    deleteSlotsToHospital(hospitalId, id).then(respp => {
      console.log(respp);
      let datta = respp.data;
      console.log(datta);
      getHospitalById(hospitalId).then(resp => {

        console.log(resp);
        resp.json().then(data => {
          console.log(data);
          setHospitalData(data);
          setSlotData(data.slots);
          let serviceNames = []
          data.services.forEach(each => {
            serviceNames.push(each.name);
          })
          setSelectValue(serviceNames);
        });
      }).catch(error => {
        console.log("login user err " + error);
      })
      setSnackMessage('Slots deleted successfully');
      setOpenSnack(true);
    });
  }

  const columns = [
    { id: 'sNo', label: 'S.NO', minWidth: 20 },
    { id: 'service', label: 'Service', minWidth: 100 },
    { id: 'date', label: 'Date', minWidth: 200 },
    { id: 'startTime', label: 'START TIME', minWidth: 100 },
    { id: 'endTime', label: 'END TIME', minWidth: 100 },
    { id: 'amount', label: 'AMOUNT($)', minWidth: 100 },
    { id: 'status', label: 'STATUS', minWidth: 200 },
    { id: 'action', label: 'ACTIONS', minWidth: 50 }
  ];

  React.useEffect(() => {
    getHospitalById(hospitalId).then(resp => {

      console.log(resp);
      resp.json().then(data => {
        console.log(data);
        setHospitalData(data);
        setSlotData(data.slots);
        let serviceNames = []
        data.services.forEach(each => {
          serviceNames.push(each.name);
        })
        setSelectValue(serviceNames);
      });
    }).catch(error => {
      console.log("login user err " + error);
    })


  }, [])
  let no = 1;

  function getDayNumberByDays(day) {
    var start = moment(new Date()), // Sept. 1st
      end = moment(new Date()).add(1, 'y');

    var result = [];
    var current = start.clone();

    while (current.day(7 + day).isBefore(end)) {
      console.log(holidays.isHoliday(current.clone().toDate()) + "--" + skipPublicHolidays);
      if (skipPublicHolidays && !holidays.isHoliday(current.clone().toDate())) {
        result.push(current.clone().toDate());
      } else if (!skipPublicHolidays) {
        result.push(current.clone().toDate());
      }

    }
    return result;
  }

  function saveSlotsHospital() {
    dailySlots.length > 0 && dailySlots.forEach(each => {
      if (each !== null && each !== "" && each !== undefined && each.timeRange !== null && each.timeRange !== "" && each.timeRange !== undefined) {
        if (each.timeRange.startTime !== null && each.timeRange.startTime !== "" && each.timeRange.startTime !== undefined && moment(each.timeRange.startTime).format('HH:mm') !== "Invalid date") {
          each.timeRange.startTime = moment(each.timeRange.startTime).format('HH:mm');
        }
        if (each.timeRange.endTime !== null && each.timeRange.endTime !== "" && each.timeRange.endTime !== undefined && moment(each.timeRange.endTime).format('HH:mm') !== "Invalid date") {
          each.timeRange.endTime = moment(each.timeRange.endTime).format('HH:mm');
        }
      }

    });

    specificSlots.length > 0 && specificSlots.forEach(each => {
      if (each !== null && each !== "" && each !== undefined && each.timeRange !== null && each.timeRange !== "" && each.timeRange !== undefined) {
        if (each.timeRange.startTime !== null && each.timeRange.startTime !== "" && each.timeRange.startTime !== undefined && moment(each.timeRange.startTime).format('HH:mm') !== "Invalid date") {
          each.timeRange.startTime = moment(each.timeRange.startTime).format('HH:mm');
        }
        if (each.timeRange.endTime !== null && each.timeRange.endTime !== "" && each.timeRange.endTime !== undefined && moment(each.timeRange.endTime).format('HH:mm') !== "Invalid date") {
          each.timeRange.endTime = moment(each.timeRange.endTime).format('HH:mm');
        }
      }
    });
    console.log(dailySlots);
    let slotList = [];
    dailySlots.length > 0 && dailySlots.forEach(each => {
      if (each !== null && each !== "" && each !== undefined && each.day !== null && each.day !== "" && each.day !== undefined &&
        !isNaN(each.amount) && each.service !== null && each.service !== "" && each.service !== undefined && each.timeRange !== null && each.timeRange !== "" && each.timeRange !== undefined) {
        let dateList = [];
        if (each.day === "SUNDAY") {
          dateList = getDayNumberByDays(1);
        } else if (each.day === "MONDAY") {
          dateList = getDayNumberByDays(2);
        } else if (each.day === "TUESDAY") {
          dateList = getDayNumberByDays(3);
        } else if (each.day === "WEDNESDAY") {
          dateList = getDayNumberByDays(4);
        } else if (each.day === "THURSDAY") {
          dateList = getDayNumberByDays(5);
        } else if (each.day === "FRIDAY") {
          dateList = getDayNumberByDays(6);
        } else {
          dateList = getDayNumberByDays(0);
        }

        dateList.forEach(eachDate => {
          slotList.push({
            //date:moment(eachDate).format("YYYY-MM-DD"),
            date: eachDate,
            startTime: each.timeRange.startTime,
            endTime: each.timeRange.endTime,
            service: each.service,
            amount: each.amount
          });
        });
      }
      console.log(slotList);
    });

    specificSlots.length > 0 && specificSlots.forEach(each => {
      if (each !== null && each !== "" && each !== undefined && each.date !== null && each.date !== "" && each.date !== undefined &&
        each.service !== null && each.service !== "" && each.service !== undefined
        && !isNaN(each.amount) && each.timeRange !== null && each.timeRange !== "" && each.timeRange !== undefined) {
        slotList.push({
          //date:moment(each.date).format("YYYY-MM-DD"),
          date: each.date,
          startTime: each.timeRange.startTime,
          endTime: each.timeRange.endTime,
          service: each.service,
          amount: each.amount
        });
      }
    });
    console.log(slotList);
    slotList.sort(function (a, b) {
      return new Date(a.date) - new Date(b.date)
    })


    slotList.length > 0 && slotList.forEach(each => {
      if (each !== null && each !== "" && each !== undefined && each.date !== null && each.date !== "" && each.date !== undefined) {
        if (each.date !== null && each.date !== "" && each.date !== undefined && moment(each.date).format("YYYY-MM-DD") !== "Invalid date") {
          each.date = moment(each.date).format("YYYY-MM-DD");
        }
      }
    });
    let arr = [];
    slotList.length > 0 && slotList.forEach(each => {
      arr.push(each);
    });
    setFinalSlots(arr);
    console.log(slotList);


    saveSlotsToHospital(hospitalId, slotList).then(respp => {
      console.log(respp);
      let datta = respp.data;
      console.log(datta);
      getHospitalById(hospitalId).then(resp => {

        console.log(resp);
        resp.json().then(data => {
          console.log(data);
          setHospitalData(data);
          setSlotData(data.slots);
          let serviceNames = []
          data.services.forEach(each => {
            serviceNames.push(each.name);
          })
          setSelectValue(serviceNames);
        });
      }).catch(error => {
        console.log("login user err " + error);
      })
      setSnackMessage('Slots added successfully');
      setOpenSnack(true);
    });
  }





  return (
    <React.Fragment>
      <>
        <DialogContent>
          <Grid container >
            <Grid md={12} >
              <Card sx={{ width: '100%', padding: '20px', backgroundColor: 'aquamarine' }}>

                <TableContainer sx={{ minHeight: 277, maxHeight: 300, width: '100%', backgroundColor: 'aquamarine' }}>
                  <Table stickyHeader aria-label="sticky table" >
                    <TableHead style={{ backgroundColor: '#566573', color: 'white' }}>
                      <TableRow style={{ borderRadius: '10px' }}>
                        {columns.map((column) => (
                          <TableCell
                            key={column.id}
                            align={column.align}
                            style={{ minWidth: column.minWidth, backgroundColor: '#566573', color: 'white', padding: '10px', }}
                            class="py-3 px-6 text-center"
                          >
                            {column.label}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody class="text-gray-200 bg-gray-700 text-sm font-light ">
                      {slotData
                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                        .map((row, ind) => {
                          return (
                            <TableRow role="checkbox" hover={true} tabIndex={-1} key={ind} style={{ textAlign: 'center' }}>
                              {columns.map((column) => {
                                const id = row["id"];
                                const value = row[column.id];
                                return (
                                  <TableCell key={column.id} align={column.align} class="py-3 px-6 text-left whitespace-nowrap">
                                    {/* {column.format && typeof value === 'number'
                                          ? column.format(value)
                                          : value} */}


                                    {(column.id === 'action') ? (
                                      <>

                                        <Tooltip title="Delete slot">
                                          <Button style={{ color: 'white', backgroundColor: "#566573", alignContent: 'center' }}
                                            onClick={() => deleteSlot(id)}
                                            aria-label="delete" >
                                            <DeleteIcon sx={{ fontSize: '20px' }} />
                                          </Button>
                                        </Tooltip>
                                      </>
                                    ) :
                                      (column.id === 'sNo') ? (
                                        ind + 1 + (page * 10)
                                      ) : (column.id === 'status') ? (
                                        <Chip label={value} style={{ backgroundColor: value === "AVAILABLE" ? ('green') : "white", color: value === "AVAILABLE" ? ('white') : "" }}></Chip>
                                      ) : (column.id === 'service') ? (
                                        <span className="bg-green-400 text-black py-1 px-3 rounded-full text-xs">{value.name}</span>
                                      ) : value}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                          );
                        })}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  rowsPerPageOptions={[5, 10, 25]}
                  component="div"
                  count={slotData.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                  class="bg-gray-900 text-white uppercase leading-normal"
                  style={{ backgroundColor: 'aquamarine' }}
                />

              </Card>

              <br></br><br></br>
              {
                <DailySlot services={selectValue} setPractice={setDailySlots} practice={dailySlots} skipPublicHolidays={skipPublicHolidays} handleSkipPublicHolidayChange={handleSkipPublicHolidayChange} />

              }


              {
                <SpecificSlot services={selectValue} setPractice={setSpecificSlots} practice={specificSlots} />

              }


            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions align='center'>

          <Button variant="contained" style={{ backgroundColor: "#566573" }} onClick={saveSlotsHospital}>&nbsp;SAVE SLOTS</Button>
          <Button variant="contained" style={{ backgroundColor: "orange" }} onClick={viewHospitalModal}>&nbsp;Close</Button>
        </DialogActions>
      </>
      <Snackbar
        style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />
    </React.Fragment>
  );
}