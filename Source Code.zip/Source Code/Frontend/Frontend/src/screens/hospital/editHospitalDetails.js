import { Checkbox, FormControl, Grid, InputLabel, ListItemText, MenuItem, OutlinedInput, Select, Snackbar, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import * as React from 'react';
import { Image } from 'react-bootstrap';
import { editHospital, getAllServices } from '../../api-service/backendServices';
import edit_hospital from '../../assets/edit_hospital.svg';
export default function EditHospital({ editHospitalModal, hospitalId, hospitalNameFromDb, streetFromDb,
    cityFromDb,
    stateFromDb, countryFromDb, zipFromDb, servicesFromDb }) {
        
    const [state, setState] = React.useState(stateFromDb);
    const [country, setCountry] = React.useState(countryFromDb);
    const [hospitalName, setHospitalName] = React.useState(hospitalNameFromDb);
    const [street, setStreet] = React.useState(streetFromDb);
    const [city, setCity] = React.useState(cityFromDb);
    const [zip, setZip] = React.useState(zipFromDb);
    let serviceNameList = [];

    servicesFromDb.forEach(each => {
        serviceNameList.push(each.name);
    })
    const [selectValue, setSelectValue] = React.useState(serviceNameList);
    const [services, setServices] = React.useState([]);
    const [snackMessage, setSnackMessage] = React.useState('');
    const [openSnack, setOpenSnack] = React.useState(false);
    const handleSnackClose = () => {
        setOpenSnack(!openSnack);
    };

    React.useEffect(() => {
        getAllServices().then(resp => {
            console.log(resp);
            let data = resp.data;
            console.log(data);
            setServices(data);
        }).catch(error => {
            console.log("login user err " + error);
        });


    }, []);

    function editHospitalById() {
        if (hospitalName === "" || hospitalName === undefined || street === "" || street === undefined ||
            city === "" || city === undefined || state === "" || state === undefined ||
            country === "" || country === undefined || zip === "" || zip === undefined
        ) {
            setSnackMessage('Fields cannot be blank');
            setOpenSnack(true);
        } else {
            editHospital(hospitalId, hospitalName, street, city, state, country, zip, selectValue).then(resp => {

                setSnackMessage('Hospital added successfully');
                setOpenSnack(true);
                editHospitalModal();
            });
        }
    }
    const handleHospitalStreetChange = (e) => {
        setStreet(e.target.value);
    };
    const handleHospitalNameChange = (e) => {
        setHospitalName(e.target.value);
    };
    const handleCityChange = (e) => {
        setCity(e.target.value);
    };

    const handleStateChange = (e) => {
        setState(e.target.value);
    };

    const handleZipChange = (e) => {
        setZip(e.target.value);
    };

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };

    const handleCountryChange = (e) => {
        setCountry(e.target.value);
    };

    const handleChange = (event) => {
        const {
            target: { value },
        } = event;
        setSelectValue(typeof value === 'string' ? value.split(',') : value);
    };
   

    return (
        <React.Fragment>
            <DialogContent>
                <Grid container >



                    <Grid item xs={6}>
                        <Image src={edit_hospital} style={{ height: '320px', width: '90%' }} />
                    </Grid>
                    <Grid item xs={6} >
                        <br></br><br></br>
                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                label="Hospital Name"
                                size="small"
                                type={'text'}
                                value={hospitalName}
                                onChange={handleHospitalNameChange}
                            />
                        </FormControl>
                        <br></br><br></br>
                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                label="Street"
                                size="small"
                                type={'text'}
                                value={street}
                                onChange={handleHospitalStreetChange}
                            />
                        </FormControl>

                        <br></br><br></br>

                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                size="small"
                                label="City"
                                type={'text'}
                                value={city}
                                onChange={handleCityChange}
                            />
                        </FormControl>
                        <br></br><br></br>

                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                size="small"
                                label="State"
                                type={'text'}
                                value={state}
                                onChange={handleStateChange}
                            />
                        </FormControl>
                        <br></br><br></br>
                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                label="Country"
                                size="small"
                                type={'text'}
                                value={country}
                                onChange={handleCountryChange}
                            />
                        </FormControl>
                        <br></br><br></br>
                        <FormControl required={true} fullWidth variant="standard" style={{ textAlign: 'center' }}>
                            <TextField
                                id="standard-adornment-fname"
                                label="Zipcode"
                                size="small"
                                type={'text'}
                                value={zip}
                                onChange={handleZipChange}
                            />
                        </FormControl>
                        <br></br><br></br>
                        <FormControl fullWidth>
                            <InputLabel id="demo-multiple-checkbox-label">Select services</InputLabel>
                            <Select
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                multiple
                                size='small'
                                value={selectValue}
                                onChange={handleChange}
                                input={<OutlinedInput label="Select services" />}
                                renderValue={(selected) => selected.join(', ')}
                                MenuProps={MenuProps}
                            >
                                {services.map((each) => (
                                    <MenuItem key={each.name} value={each.name}>
                                        <Checkbox checked={selectValue.indexOf(each.name) > -1} />
                                        <ListItemText primary={each.name} />
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>

                    </Grid>



                </Grid>
            </DialogContent>
            <DialogActions align='center'>
                <Button variant="contained" style={{ backgroundColor: "green" }} onClick={editHospitalById}>&nbsp;Update</Button>
                <Button variant="contained" style={{ backgroundColor: "orange" }} onClick={editHospitalModal}>&nbsp;Close</Button>
            </DialogActions>
            <Snackbar
                style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
                autoHideDuration={3000}
                anchorOrigin={{
                    vertical: "center",
                    horizontal: "center"
                }}
                open={openSnack}
                onClose={handleSnackClose}
                message={snackMessage}
            />
        </React.Fragment>
    );
}