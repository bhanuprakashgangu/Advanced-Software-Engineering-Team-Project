import LoginIcon from '@mui/icons-material/Login';
import {
  FormControl, Grid, Snackbar, TextField
} from '@mui/material';
import Button from '@mui/material/Button';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import * as React from 'react';
import { loginUser } from '../../api-service/backendServices';
export default function Login({ toggleModal, loginButton }) {


  //This js file is to handle login user related design & backend API calls
  const [openSnack, setOpenSnack] = React.useState(false);
  const [lusername, setLUsername] = React.useState("");
  const [lpassword, setLPassword] = React.useState("");
  const [invalidError, setInvalidError] = React.useState('');
  const [isSignUpOpen, setIsSignUpOpen] = React.useState(false);
  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };
  const lpasswordChange = (event) => {
    setLPassword(event.target.value);
  }

  const lusernameChange = (event) => {
    setLUsername(event.target.value);
  }


  const clickLogin = () => {
    if (lusername === "" || lusername === undefined || lpassword === "" || lpassword === undefined) {
      setOpenSnack(true);
    } else {
      loginUser(lusername, lpassword).then(resp => {
        console.log(resp);
        resp.json().then(data => {
          console.log(data);

          if (data !== null && data.email !== undefined && data.email !== "" && data.email !== "undefined"
            && data.email !== null) {
            localStorage.setItem("firstname", data.firstName);
            localStorage.setItem("lastname", data.lastName);
            localStorage.setItem("email", data.email);
            localStorage.setItem("userId", data.id);
            localStorage.setItem("token", data.token);
            localStorage.setItem("role", data.role);

            loginButton("LOGOUT");
            toggleModal();
          } else {
            setInvalidError('Invalid credentials!');
          }
        });
      }).catch(error => {
        console.log("login user err " + error);
      })
    }
  }



  return (
    <React.Fragment>
      <Grid container style={{ width: '1500px !important' }}>
        <Grid item xs={12}>
          <DialogContent style={{ overflowY: 'unset' }}>
            <FormControl required={true} fullWidth variant="outlined" style={{ textAlign: 'center' }}>
              <TextField
                size="small"
                label="Email"
                id="standard-adornment-lusername"
                type={'text'}
                defaultValue={lusername}
                onBlur={lusernameChange}
              />
            </FormControl><br></br><br></br>
            <FormControl required={true} fullWidth variant="outlined" style={{ textAlign: 'center' }}>

              <TextField
                size="small"
                label="Password"
                id="standard-adornment-lpassword"
                type={'password'}
                defaultValue={lpassword}
                onBlur={lpasswordChange}
              />
            </FormControl>
            <br></br>
            <span style={{
              fontWeight: 'bold',
              color: 'red',
            }}>{invalidError}</span>

          </DialogContent>
          <DialogActions align='center' style={{ justifyContent: 'center' }}>
            <Button variant="contained" style={{ backgroundColor: "#566573" }} onClick={clickLogin}><LoginIcon />&nbsp;LOGIN</Button>

          </DialogActions>

          <Snackbar
            style={{ whiteSpace: 'pre-wrap', width: '300px', top: '50%', bottom: '50%', left: '40%', right: '50%' }}
            autoHideDuration={1300}
            anchorOrigin={{
              vertical: "center",
              horizontal: "center"
            }}
            open={openSnack}
            onClose={handleSnackClose}
            message="Please fill out this field"
          />
        </Grid>
      </Grid>
    </React.Fragment>

  );
}