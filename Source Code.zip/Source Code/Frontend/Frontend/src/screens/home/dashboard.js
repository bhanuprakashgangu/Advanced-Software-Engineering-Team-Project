import LoginIcon from '@mui/icons-material/Login';
import PlaylistAddCheckCircleIcon from '@mui/icons-material/PlaylistAddCheckCircle';
import { Box, FormControl, Grid, InputLabel, MenuItem, Select, Snackbar, TextField } from '@mui/material';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import * as React from 'react';
import { deleteHospitals, getAllHospitalDetails, getHospitalById, registerUser } from '../../api-service/backendServices';
import add from '../../assets/add.png';
import deletes from '../../assets/delete.png';
import edit from '../../assets/edit.png';
import registerImg from '../../assets/register.jpg';
import slot from '../../assets/slot.png';
import Header from '../navbar/Navbar';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import IconButton from '@mui/material/IconButton';
import { styled } from '@mui/material/styles';
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import SearchIcon from "@mui/icons-material/Search";
import InputAdornment from "@mui/material/InputAdornment";
import { Image } from 'react-bootstrap';
import AddNewHospital from '../hospital/addNewHospital';
import EditHospital from '../hospital/editHospitalDetails';
import ViewHospital from '../hospital/viewHospitalDetails';
import ViewSlot from '../hospital/ViewHospitalSlot';
import Login from '../login/Login';
export default function Dashboard() {
  const [eStreet, seteStreet] = React.useState('');
  const [eCity, seteCity] = React.useState('');
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [openSnack, setOpenSnack] = React.useState(false);
  const [snackMessage, setSnackMessage] = React.useState('');
  const [eState, seteState] = React.useState('');
  const [isAddHospitalOpen, setIsAddHospitalOpen] = React.useState(false);
  const [isEditHospitalOpen, setIsEditHospitalOpen] = React.useState(false);
  const [value, setValue] = React.useState(1);
  const [hospitalsData, setHospitalsData] = React.useState([]);
  const [isOpen, setIsOpen] = React.useState(false);
  const [isViewHospitalOpen, setIsViewHospitalOpen] = React.useState(false);
  const [isViewSlotOpen, setIsViewSlotOpen] = React.useState(false);
  const [clickHospitaldId, setClickHospitaldId] = React.useState('');
  const [logButtonName, setlogButtonName] = React.useState("LOGIN");
  const [eHospitalId, seteHospitalId] = React.useState('');
  const [eHospitalName, seteHospitalName] = React.useState('');
  const [eServices, seteservices] = React.useState([]);
  const [eselectValue, seteSelectValue] = React.useState([]);
  const [eCountry, seteCountry] = React.useState('');
  const [eZip, setezip] = React.useState('');
  const loginHandler = (value) => {
    setIsLoggedIn(value);
  }
  React.useEffect(() => {
    getLoggedInStatus();

  }, [value]);



  React.useEffect(() => {
    getAllHospitalDetails("").then(resp => {
      console.log(resp);
      resp.json().then(data => {
        setHospitalsData(data);
      });
    }).catch(error => {
      console.log("Error occured in get all hospitalDetails " + error);
    })
  }, [isLoggedIn])

  function toggleAddHospitalSlotsModal() {
    setIsViewHospitalOpen(!isViewHospitalOpen);
  }

  function toggleViewHospitalSlotsModal() {
    setIsViewSlotOpen(!isViewSlotOpen);
  }

  const handleSnackClose = () => {
    setOpenSnack(!openSnack);
  };

  const editHospital = (id, index) => {
    seteHospitalId(id);
    seteState(hospitalsData[index].state);
    seteCountry(hospitalsData[index].country);
    setezip(hospitalsData[index].zipcode);
    seteservices(hospitalsData[index].services)
    seteHospitalName(hospitalsData[index].name);
    seteStreet(hospitalsData[index].street);
    seteCity(hospitalsData[index].city);
    toggleEditHospitalDetailsModal();
  }

  const deleteHospitalById = (id) => {
    console.log(id);
    deleteHospitals(id).then(resp => {
      if (resp.status === 500) {
        setSnackMessage('Exception occured during delete hospital, Please check the logs');
        setOpenSnack(true);
      } else {
        setSnackMessage('Hospital deleted successfully');
        setOpenSnack(true);
        getAllHospitalDetails("").then(resp => {
          resp.json().then(data => {
            console.log(data);
            setHospitalsData(data);
          });
        }).catch(error => {
          console.log("login user err " + error);
        });
      }

    }).catch(error => {
      console.log("login user err " + error);
    })
  }

  function addSlotsToHospital(id) {
    if (localStorage.getItem('email') === "" || localStorage.getItem('email') === null) {
      setSnackMessage("Please login, before booking");
      setOpenSnack(!openSnack);
      return false;
    }

    console.log(id);
    setClickHospitaldId(id);
    toggleAddHospitalSlotsModal()

  }

  function viewHospitalSlots(id) {


    if (localStorage.getItem('email') === "" || localStorage.getItem('email') === null) {
      setSnackMessage("Please login, before booking");
      setOpenSnack(!openSnack);
      return false;
    }

    console.log(id);
    setClickHospitaldId(id);
    toggleViewHospitalSlotsModal();

  }

  const clickLogin = () => {
    toggleModal();
  }

  function getLoggedInStatus() {
    if (localStorage.getItem("email") !== "" && localStorage.getItem("email") !== undefined
      && localStorage.getItem("email") !== null) {
      console.log("LOgged in already");
      setIsLoggedIn(true);
    } else {
      console.log("LOgged in not yet");
      setIsLoggedIn(false);
    }
  }

  const DialogAddSlot = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
      padding: theme.spacing(2),
      minWidth: '1500px !important',
      height: '800px'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));

  const DialogLogin = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
      minWidth: '600px !important',
      height: '300px',
      overflowY: 'none'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
      overflowY: 'none'
    },
  }));
  const DialogForViewHospitalDetails = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
      padding: theme.spacing(2),
      minWidth: '800px !important',
      height: '500px'
    },
    '& .MuiDialogActions-root': {
      padding: theme.spacing(1),
    },
  }));
  const DialogTitleForModal = (props) => {
    const { children, onClose, ...other } = props;
    return (
      <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
        {children}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
          </IconButton>
        ) : null}
      </DialogTitle>
    );
  };


  DialogTitleForModal.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
  };



  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    seteSelectValue(typeof value === 'string' ? value.split(',') : value);
  };
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  //This function is to validate user session exists or not
  function isUserSessionAlreadyExist() {
    if (localStorage.getItem("email") !== "" && localStorage.getItem("email") !== undefined
      && localStorage.getItem("email") !== null) {
      loginHandler(true);
      return "LOGOUT";
    } else {
      loginHandler(false);
      return "LOGIN";
    }
  }

  function toggleModal() {
    //alert(selectValue);
    if (logButtonName === 'LOGOUT') {
      // logoutUser(localStorage.getItem("userId")).then(resp => {
      //   console.log(resp);
      //   resp.json().then(data => {
      //     console.log(data);
      //   });
      // });
      localStorage.removeItem("firstname");
      localStorage.removeItem("lastname");
      localStorage.removeItem("email");
      localStorage.removeItem("userId");
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      setlogButtonName("LOGIN");
      window.location.replace("/")
    } else {
      setIsOpen(!isOpen);
      getAllHospitalDetails("").then(resp => {
        console.log(resp);
        resp.json().then(data => {
          console.log(data);
          setHospitalsData(data);

        });
      }).catch(error => {
        console.log("login user err " + error);
      })
    }
  }
  function toggleAddHospitalModal() {
    setIsAddHospitalOpen(!isAddHospitalOpen);
    if (isAddHospitalOpen === true) {
      getAllHospitalDetails("").then(resp => {
        console.log(resp);
        resp.json().then(data => {
          console.log(data);
          setHospitalsData(data);

        });
      }).catch(error => {
        console.log("login user err " + error);
      });




    }
  }

  function toggleEditHospitalDetailsModal() {
    setIsEditHospitalOpen(!isEditHospitalOpen);
    if (isEditHospitalOpen === true) {
      getAllHospitalDetails("").then(resp => {
        resp.json().then(data => {
          console.log(data);
          setHospitalsData(data);

        });
      }).catch(error => {
        console.log("login user err " + error);
      });
    }
  }

  const [emailError, setEmailError] = React.useState('');
  const [mobileError, setMobileError] = React.useState('');
  const [cpasswordError, setcPasswordError] = React.useState('');
  const [invalidError, setInvalidError] = React.useState('');
  const passwordChange = (event) => {
    setPassword(event.target.value);
  }

  const confirmPasswordChange = (event) => {
    setCPassword(event.target.value);
  }

  const emailChange = (event) => {
    setEmail(event.target.value);
    if (!ValidateEmail(event.target.value)) {
      setEmailError('Enter valid Email!');
    } else {
      setEmailError('');
    }
  }

  const firstNameChange = (event) => {
    setFName(event.target.value);
  }

  const lastNameChange = (event) => {
    setLName(event.target.value);
  }

  const roleChange = (event) => {
    setRole(event.target.value);
  }

  const clickRegister = () => {

    if (email === "" || email === undefined || password === "" || password === undefined ||
      firstName === "" || firstName === undefined || lastName === "" || lastName === undefined || role === "" || role === undefined) {
      setSnackMessage('Please fill out this field');
      setOpenSnack(true);
    } else if (!ValidateEmail(email)) {
      return false;
    } else if (password != confirmPassword) {
      setcPasswordError('Password mismatched!');
      return false;
    } else {
      registerUser(firstName, lastName, email, password, role).then(res => {
        console.log(res)
        if (res.ok) {
          setFName("");
          setLName("");
          setEmail("");
          setPassword("");
          setCPassword("");
          setcPasswordError("");
          setSnackMessage('Registration success!, Please log in');
          setOpenSnack(true);
        } else {
          res.text().then(text => {
            let err = JSON.parse(text);
            console.log(err);
            setcPasswordError(err.message);
            setSnackMessage(err.message);
            setOpenSnack(true);
          })
        }

      })
        .catch(error => {
          console.log("Regiter failed" + error);
          setInvalidError('Registration Failed!');
        })
    }
  }

  function ValidateEmail(mail) {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
      return (true)
    }
    return (false)
  }
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirmPassword, setCPassword] = React.useState("");
  const [firstName, setFName] = React.useState("");
  const [lastName, setLName] = React.useState("");
  const [role, setRole] = React.useState("");

  return (
    <React.Fragment>
      <Header loginHandler={loginHandler} />
      <br></br><br></br><br></br><br></br><br></br>

      {(localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "" ? (
        <>
          <FormControl fullWidth variant='standard' required={true} style={{ textAlign: 'center', marginLeft: '100px', width: '75%' }}>
            <TextField
              size="small"
              label="Search Hospital / Location / services"

              style={{ backgroundColor: "white" }}
              onChange={event => {
                let val = event.target.value;
                getAllHospitalDetails(val).then(resp => {
                  console.log(resp);
                  resp.json().then(data => {
                    console.log(data);
                    setHospitalsData(data);

                  });
                }).catch(error => {
                  console.log("login user err " + error);
                })
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment>
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                )


              }}
            /></FormControl>

          {(localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "" && localStorage.getItem("role").trim() === "admin") ? (
            // <Button variant="contained" style={{ backgroundColor: "darkkhaki", float: 'right', marginRight:'2%'}}  onClick={toggleAddHospitalModal} ><AddCircleOutlineIcon />&nbsp;ADD HOSPITAL</Button>
            <Image src={add} onClick={toggleAddHospitalModal} style={{ float: 'right', height: '120px', marginRight: '3%', marginTop: '-10px', cursor: 'pointer' }}></Image>
          ) : ""}
          <br></br><br></br>
          <Grid container direction="row" rowSpacing={2} style={{ paddingLeft: '100px' }} spacing={{ xs: 2, md: 4 }} columns={{ xs: 4, sm: 8, md: 12 }}>




            {hospitalsData.length > 0 ? (hospitalsData.map((each, index) => (
              <Grid item key={index}>
                <Card sx={{ minWidth: '250px', maxWidth: '250px', borderRadius: '20px' }} >
                  <CardMedia
                    component="img"
                    image="https://cdn-icons-png.flaticon.com/512/2785/2785491.png"
                    style={{ height: '120px', width: '120px', marginLeft: 'auto', marginRight: 'auto' }}
                    alt="Paella dish"
                  />

                  <CardContent style={{ minHeight: '180px', fontFamily: 'fantasy' }}>
                    <Typography gutterBottom variant="h6" component="div" style={{ fontFamily: 'fantasy', fontSize: 14, fontWeight: '500', color: '#566573' }}>
                      {each.name.toUpperCase()}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {each.street},
                    </Typography>
                    <Typography variant="body2" color="text.secondary" >
                      {each.city},
                    </Typography>
                    <Typography variant="body2" color="text.secondary" >
                      {each.state},
                    </Typography>
                    <Typography variant="body2" color="text.secondary" >
                      {each.country}-{each.zipcode}
                    </Typography>
                  </CardContent>

                  {(localStorage.getItem("email") !== undefined && localStorage.getItem("email") !== null && localStorage.getItem("email").trim() !== "" && localStorage.getItem("role").trim() === "admin") ? (
                    <CardActions style={{ backgroundColor: '#566573', color: 'white', display: "flex", justifyContent: 'center !important', padding: '10px' }}>

                      <Button size="large">
                        <Image src={edit} onClick={(e) => editHospital(each.id, index)} style={{ float: 'right', height: '40px', cursor: 'pointer' }}></Image>
                      </Button>
                      &nbsp; &nbsp;
                      <Button size="large">
                        <Image src={slot} onClick={(e) => addSlotsToHospital(each.id)} style={{ float: 'right', height: '40px', cursor: 'pointer' }}></Image>&nbsp;
                      </Button>

                      &nbsp; &nbsp;
                      <Button size="large">
                        <Image src={deletes} onClick={(e) => deleteHospitalById(each.id)} style={{ float: 'right', height: '40px', cursor: 'pointer' }}></Image>
                      </Button>
                      &nbsp; &nbsp;
                    </CardActions>
                  ) : (
                    <CardActions style={{ backgroundColor: '#566573', color: 'white', display: "flex", justifyContent: 'center', padding: '10px' }}>
                      <Button style={{ color: 'white', border: '1px solid white' }} aria-label="edit" onClick={(e) => viewHospitalSlots(each.id)} size="large">
                        <PlaylistAddCheckCircleIcon />&nbsp;CHECK AVAILABILITY
                      </Button>
                    </CardActions>
                  )}
                </Card>
              </Grid>

            ))) : ""
            }

          </Grid>
          <br></br><br></br><br></br>
        </>
      ) : (
        <Grid container direction="row" rowSpacing={1} style={{ padding: '30px' }}>

          <Grid md={3}></Grid>
          <Grid md={6}>
            <Card style={{ padding: '20px' }}>
              <CardMedia
                component="img"
                height="140"
                image={registerImg}
              />
              <CardContent>
                <FormControl required={true} fullWidth sx={{ m: 1 }} variant="outlined" style={{ textAlign: 'center' }}>
                  <TextField
                    label="First Name"
                    size="small"
                    id="standard-adornment-firstName"
                    type={'text'}
                    value={firstName}
                    onChange={firstNameChange}
                  />
                </FormControl><br></br>

                <FormControl required={true} fullWidth sx={{ m: 1 }} variant="outlined" 
                    style={{ textAlign: 'center' }}>
                  <TextField
                    label="Last Name"
                    size="small"
                    id="standard-adornment-lastName"
                    type={'text'}
                    value={lastName}
                    onChange={lastNameChange}
                  />
                </FormControl><br></br>

                <FormControl style={{ textAlign: 'center' }} required={true} fullWidth sx={{ m: 1 }} variant="outlined" >
                  <TextField
                    label="Email"
                    size="small"
                    id="standard-adornment-email"
                    type={'text'}
                    value={email}
                    onChange={emailChange}
                  />
                </FormControl>
                <br></br>
                <span style={{
                  color: 'red',
                }}>{emailError}</span>

                <FormControl style={{ textAlign: 'center' }} required={true} fullWidth sx={{ m: 1 }} variant="outlined" >
                  <TextField
                    label="Password"
                    size="small"
                    id="standard-adornment-password"
                    type={'password'}
                    value={password}
                    onChange={passwordChange}
                  />
                </FormControl>
                <br></br>
                <FormControl style={{ textAlign: 'center' }} required={true} fullWidth sx={{ m: 1 }} variant="outlined" >
                  <TextField
                    label="Confirm Password"
                    size="small"
                    id="standard-adornment-confirmPassword"
                    type={'password'}
                    value={confirmPassword}
                    onChange={confirmPasswordChange}
                  />
                </FormControl>
                <br></br>
                <FormControl variant="outlined" fullWidth required={true} sx={{ m: 1 }} >
                  <InputLabel id="demo-simple-select-label">Role</InputLabel>
                  <Select
                    style={{ height: '45px' }}
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={role}
                    label="Role"
                    onChange={roleChange}
                  >
                    <MenuItem value={"admin"}>ADMIN</MenuItem>
                    <MenuItem value={"user"}>USER</MenuItem>
                  </Select>
                </FormControl>
                <br></br>
                <span style={{
                  fontWeight: 'bold',
                  color: 'red',
                }}>{cpasswordError}</span>
              </CardContent>
              <CardActions style={{ justifyContent: 'center' }}>
                <Box style={{ alignSelf: 'center' }}>
                  <Button variant="contained" style={{ backgroundColor: 'goldenrod' }} onClick={clickRegister} ><PersonAddAlt1Icon />&nbsp;CREATE ACCOUNT</Button>

                  <br></br><br></br>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<Button variant="contained" style={{ backgroundColor: '#566573' }} onClick={clickLogin} ><LoginIcon />&nbsp;LOGIN</Button>



                </Box></CardActions>
            </Card>

          </Grid>
          <Grid md={3}></Grid>

        </Grid>
      )
      )}

      <DialogLogin
        onClose={toggleModal}
        aria-labelledby="customized-dialog-title"
        open={isOpen}

      >
        <DialogTitleForModal id="customized-dialog-title" onClose={toggleModal} className="toolHeader" style={{ textAlign: 'center', backgroundColor: '#566573', color: 'white' }}>
          LOGIN
        </DialogTitleForModal>

        <Login toggleModal={toggleModal} loginButton={setlogButtonName} />
      </DialogLogin>

      <DialogAddSlot
        onClose={toggleAddHospitalModal}
        aria-labelledby="customized-dialog-title"
        open={isAddHospitalOpen}
      >
        <DialogTitleForModal id="customized-dialog-title" className="toolHeader" style={{ textAlign: 'center', color: 'black' }}>
          ADD NEW HOSPITAL
        </DialogTitleForModal>

        <AddNewHospital addHospitalModal={toggleAddHospitalModal} />

      </DialogAddSlot>
      <DialogForViewHospitalDetails
        onClose={toggleEditHospitalDetailsModal}
        aria-labelledby="Edit-Hospital-Details"
        open={isEditHospitalOpen}
      >
        <DialogTitleForModal id="Edit-Hospital-Details" className="toolHeader" 
        style={{ textAlign: 'center', color: 'black' }}>
          EDIT HOSPITAL DETAILS
        </DialogTitleForModal>

        <EditHospital editHospitalModal={toggleEditHospitalDetailsModal} hospitalId={eHospitalId} hospitalNameFromDb={eHospitalName}
          streetFromDb={eStreet} cityFromDb={eCity} stateFromDb={eState} countryFromDb={eCountry} zipFromDb={eZip} servicesFromDb={eServices}
        />


      </DialogForViewHospitalDetails>



      <Snackbar
        style={{ top: '50%', bottom: '50%', left: '40%', right: '50%' ,whiteSpace: 'pre-wrap', width: '300px'}}
        autoHideDuration={4000}
        anchorOrigin={{
          vertical: "center",
          horizontal: "center"
        }}
        open={openSnack}
        onClose={handleSnackClose}
        message={snackMessage}
      />

<DialogAddSlot
        onClose={toggleViewHospitalSlotsModal}
        aria-labelledby="View-Hospital-Slots"
        open={isViewSlotOpen}
        onBackdropClick="false"
      >
        <DialogTitleForModal id="View-Hospital-Slots" className="toolHeader" style={{ textAlign: 'center', color: 'black' }}>
          VIEW HOSPITAL SLOTS
        </DialogTitleForModal>

        <ViewSlot viewSlotModal={toggleViewHospitalSlotsModal}
          hospitalId={clickHospitaldId} />


      </DialogAddSlot>

<DialogAddSlot
        onClose={toggleAddHospitalSlotsModal}
        aria-labelledby="Add-Hospital-Slots"
        open={isViewHospitalOpen}
        onBackdropClick="false"
      >
        <DialogTitleForModal id="Add-Hospital-Slots" className="toolHeader" style={{ textAlign: 'center', color: 'black' }}>
          ADD HOSPITAL SLOTS
        </DialogTitleForModal>

        <ViewHospital viewHospitalModal={toggleAddHospitalSlotsModal}
          hospitalId={clickHospitaldId} />


      </DialogAddSlot>
    </React.Fragment>
  );
}