import AddBoxIcon from '@mui/icons-material/AddBox';
import { Button, Card, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Tooltip, createTheme, ThemeProvider, createMuiTheme } from "@mui/material";
import { LocalizationProvider, MobileTimePicker, TimePicker } from "@mui/x-date-pickers";
import { makeStyles, withStyles } from "@mui/styles";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import React from "react";
import { Image } from "react-bootstrap";
import deletes from '../../assets/delete.png';
import daywise from '../../assets/daywise.svg';
export default function DayWiseSlotsDetails({ services, setInputFields, inputFields, setPractice }) {

    const addInputField = () => {
        setInputFields([...inputFields, {
            day: '',
            service: '',
            amount: 0,
            timeRange: {
                startTime: '',
                endTime: ''
            }
        }])
        setPractice([...inputFields, {
            day: '',
            service: '',
            amount: 0,
            timeRange: {
                startTime: '',
                endTime: ''
            }
        }]);
    }
    const removeInputFields = (pos) => {
        const rows = [...inputFields];
        rows.splice(pos, 1);
        setInputFields(rows);
        setPractice(rows);
        //setLessons(rows);
    }

    const handleDayChange = (pos, evnt) => {

        const { name, value } = evnt.target;
        const list = [...inputFields];
        list[pos][name] = value;
        setInputFields(list);
        setPractice(list);
    }

    const handleFeatureChange = (pos, e) => {
        const list = [...inputFields];
        list[pos].service = e.target.value;
        console.log(list);
        setInputFields(list);
        setPractice(list);
    };

    const handleAmountChange = (pos, e) => {
        const list = [...inputFields];
        console.log(e);
        list[pos].amount = e.target.value;
        console.log(list);
        setInputFields(list);
        setPractice(list);
    };

    const StartDatesChange = (pos, value) => {
        const list = [...inputFields];
        list[pos].timeRange.startTime = value;
        console.log(list);
        setInputFields(list);
        setPractice(list);
    }

    const handleEndTimeChange = (pos, value) => {
        //const { name, value } = evnt.target;
        const list = [...inputFields];
        list[pos].timeRange.endTime = value;
        console.log(list);
        setInputFields(list);
        setPractice(list);
    }

  const theme = createTheme({
    palette: {
        mode:'dark',
        primary: {
            main:'#00cc99',
            dark:'#00cc99'
        },
        info:{
            main:'#ffffff',
            dark:'#ffffff'
        },
        text:{
            primary:'#00cc99',
            secondary:'#00cc99'
        },
        
      }
  });
    return (
        <>
            <Button variant="contained" style={{ backgroundColor: "#566573", float: 'right', marginRight: '90px' }} onClick={addInputField}><AddBoxIcon />&nbsp;ADD DAYWISE SLOT</Button>
            <br></br><br></br>
            {(inputFields.map((data, pos) => {

                const { day, service, amount, timeRange } = data;
                const { startTime, endTime } = timeRange;
                return (
                    <>
                        <Card style={{ padding: '10px', backgroundColor: 'azure' }}>
                            <Grid container direction={"row"}>
                                <Grid md={4}>
                                    <Image src={daywise} style={{ float: 'left', height: '200px', cursor: 'pointer' }}></Image>
                                </Grid>
                                <Grid md={8}>

                                    <FormControl required={true} style={{ maxWidth: '50% !important' }} variant="standard" >

                                        <TextField
                                            id="outlined-select-currency"
                                            select
                                            label="Select hospital service"
                                            value={service}
                                            onChange={(val) => handleFeatureChange(pos, val)}
                                            helperText="Please select service for this slot"
                                        >
                                            {services.map((option) => (
                                                <MenuItem key={option} value={option}>
                                                    {option}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </FormControl>&nbsp;&nbsp;&nbsp;
                                    <FormControl sx={{ minWidth: 120 }}>
                                        <InputLabel htmlFor="standard-adornment-fname">Select Day</InputLabel>
                                        <Select
                                            labelId="demo-simple-select-standard-label"
                                            id="demo-simple-select-day"
                                            value={day}
                                            name="day"
                                            style={{ width: '150px' }}
                                            onChange={(evnt) => handleDayChange(pos, evnt)}
                                            label="Select Day"
                                        >
                                            <MenuItem value="" disabled>
                                                <em>None</em>
                                            </MenuItem>
                                            <MenuItem value={"SUNDAY"}>SUNDAY</MenuItem>
                                            <MenuItem value={"MONDAY"}>MONDAY</MenuItem>
                                            <MenuItem value={"TUESDAY"}>TUESDAY</MenuItem>
                                            <MenuItem value={"WEDNESDAY"}>WEDNESDAY</MenuItem>
                                            <MenuItem value={"THURSDAY"}>THURSDAY</MenuItem>
                                            <MenuItem value={"FRIDAY"}>FRIDAY</MenuItem>
                                            <MenuItem value={"SATURDAY"}>SATURDAY</MenuItem>
                                        </Select>
                                    </FormControl> &nbsp;&nbsp;&nbsp;
                                    <ThemeProvider theme={theme}>  
                                    <LocalizationProvider dateAdapter={AdapterDateFns} style={{ maxWidth: '50% !important' }}>
                                        <MobileTimePicker
                                            label="Start Time"
                                            value={startTime}
                                            style={{ maxWidth: '50% !important' }}
                                            name="startTime"
                                            onChange={(val) => StartDatesChange(pos, val)}
                                            renderInput={(params) => <TextField 
                                                helperText="Select slot start time" {...params} 
                                                sx={{
                                                    '& .MuiOutlinedInput-root': {
                                                      '& fieldset': {
                                                        borderColor: 'red',
                                                      },
                                                      '&:hover fieldset': {
                                                        borderColor: 'green',
                                                      },
                                                      '&.Mui-focused fieldset': {
                                                        borderColor: 'purple',
                                                      },
                                                    },
                                                  }}
                                                style={{ maxWidth: '50% !important', color:'black', borderColor:'darkgray' }} />}
                                        /></LocalizationProvider></ThemeProvider> &nbsp;&nbsp;&nbsp;
                                    <ThemeProvider theme={theme}>  
                                    <LocalizationProvider dateAdapter={AdapterDateFns} style={{ maxWidth: '50% !important' }}>
                                        <MobileTimePicker
                                            label="Finish Time"
                                            value={endTime}
                                            style={{ maxWidth: '50% !important' }}
                                            name="endTime"
                                            onChange={(val) => handleEndTimeChange(pos, val)}
                                            renderInput={(params) => 
                                            <TextField helperText="Select slot end time" 
                                            sx={{
                                                '& .MuiOutlinedInput-root': {
                                                  '& fieldset': {
                                                    borderColor: 'red',
                                                  },
                                                  '&:hover fieldset': {
                                                    borderColor: 'green',
                                                  },
                                                  '&.Mui-focused fieldset': {
                                                    borderColor: 'purple',
                                                  },
                                                },
                                              }}
                                            {...params} style={{ maxWidth: '50% !important' }} 
                                            />}
                                        /></LocalizationProvider></ThemeProvider>
                                        
                                    &nbsp;&nbsp;&nbsp;
                                    <FormControl required={true} variant="standard" style={{ textAlign: 'center', width: '100px' }}>
                                        <TextField
                                            id="standard-adornment-fname"
                                            label="Slot price($)"
                                            type={'text'}
                                            value={amount}
                                            helperText="Select slot price"
                                            onChange={(val) => handleAmountChange(pos, val)}
                                            style={{ width: '100px' }} />
                                    </FormControl>
                                    &nbsp;&nbsp;&nbsp;
                                    <Tooltip title="Delete slot">

                                        <Button size="large">
                                            <Image src={deletes} onClick={(e) => removeInputFields(pos)} style={{ float: 'right', height: '50px', cursor: 'pointer' }}></Image>
                                        </Button>

                                    </Tooltip>
                                </Grid></Grid>
                        </Card><br></br>
                    </>
                )
            }))
            }
        </>
    )
};