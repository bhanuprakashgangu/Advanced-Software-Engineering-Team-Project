import AddBoxIcon from '@mui/icons-material/AddBox';
import { Button, Card, createTheme, FormControl, Grid, MenuItem, TextField, ThemeProvider, Tooltip } from "@mui/material";
import { DesktopDatePicker, LocalizationProvider, MobileTimePicker, TimePicker } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import React from "react";
import { Image } from "react-bootstrap";
import deletes from '../../assets/delete.png';
import add_particular_slot from '../../assets/add_particular_slot.svg';
export default function ParticularDaySlotDetails({ services, setInputFields, inputFields, setPractice, practice }) {

  const addSlotInputField = () => {
    setInputFields([...inputFields, {
      date: '',
      service: '',
      amount: '',
      timeRange: {
        startTime: '',
        endTime: ''
      }
    }])
    setPractice([...inputFields, {
      date: '',
      service: '',
      amount: '',
      timeRange: {
        startTime: '',
        endTime: ''
      }
    }]);
  }
  const removeInputFields = (pos) => {
    const rows = [...inputFields];
    rows.splice(pos, 1);
    setInputFields(rows);
    setPractice(rows);
    //setLessons(rows);
  }

  const handleChange = (pos, evnt) => {

    const { name, value } = evnt.target;
    const list = [...inputFields];
    list[pos][name] = value;
    setInputFields(list);
    setPractice(list);
    // setLessons(list);
  }

  const handleServiceChange = (pos, e) => {
    const list = [...inputFields];
    list[pos].service = e.target.value;
    console.log(list);
    setInputFields(list);
    setPractice(list);
  };

  const handleDateChange = (pos, value) => {
    const list = [...inputFields];
    list[pos].date = value;
    console.log(list);
    setInputFields(list);
    setPractice(list);
  }

  const handleAmountChange = (pos, e) => {
    const list = [...inputFields];
    list[pos].amount = e.target.value;
    console.log(list);
    setInputFields(list);
    setPractice(list);
  };


  const handleSDateChange = (pos, value) => {
    const list = [...inputFields];
    list[pos].timeRange.startTime = value;
    console.log(list);
    setInputFields(list);
    setPractice(list);
  }

  const handleEDateChange = (pos, value) => {
    const list = [...inputFields];
    list[pos].timeRange.endTime = value;
    console.log(list);
    setInputFields(list);
    setPractice(list);
  }

  const theme = createTheme({
    palette: {
        mode:'dark',
        primary: {
            main:'#00cc99',
            dark:'#00cc99'
        },
        info:{
            main:'#ffffff',
            dark:'#ffffff'
        },
        text:{
            primary:'#00cc99',
            secondary:'#00cc99'
        },
        
      }
  });
  return (
    <>
      <Button variant="contained" style={{
        float: 'right', marginRight: '90px', backgroundColor: "#566573",
      }} onClick={addSlotInputField}><AddBoxIcon />&nbsp;ADD PARTICULAR DAY SLOT</Button>
      <br></br><br></br>
      {(inputFields.map((data, pos) => {

        const { date, service, amount, timeRange } = data;
        const { startTime, endTime } = timeRange;
        return (
          <>
            <Card style={{ padding: '10px', backgroundColor: 'azure' }}>
              <Grid container direction={"row"}>
                <Grid md={4}>
                  <Image src={add_particular_slot} style={{ float: 'left', height: '200px', cursor: 'pointer' }}></Image>
                </Grid>
                <Grid md={8}>
                  <FormControl required={true} style={{ maxWidth: '20% !important' }} variant="standard" >

                    <TextField
                      id="outlined-select-currency"
                      select
                      label="Select Hospital service"
                      value={service}
                      onChange={(val) => handleServiceChange(pos, val)}
                      helperText="Please select any one hospital service"
                    >
                      {services.map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </TextField>
                  </FormControl>&nbsp;&nbsp;&nbsp;
                  <LocalizationProvider dateAdapter={AdapterDateFns} style={{ maxWidth: '20% !important' }}>
                    <DesktopDatePicker
                      label="Select date"
                      value={date}
                      disablePast="true"
                      fullWidth
                      onChange={(val) => handleDateChange(pos, val)}
                      renderInput={(params) => <TextField {...params} helperText="Select slot date" />}
                    /></LocalizationProvider> &nbsp;&nbsp;&nbsp;


<ThemeProvider theme={theme}>
                  <LocalizationProvider dateAdapter={AdapterDateFns} style={{ maxWidth: '20% !important' }}>
                    <MobileTimePicker
                      label="Start Slot Time"
                      value={startTime}
                      style={{ maxWidth: '20% !important' }}
                      name="startTime"
                      format="hh:mm:ss"
                      onChange={(val) => handleSDateChange(pos, val)}
                      renderInput={(params) => <TextField 
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderColor: 'red',
                            },
                            '&:hover fieldset': {
                              borderColor: 'green',
                            },
                            '&.Mui-focused fieldset': {
                              borderColor: 'purple',
                            },
                          },
                        }}
                        helperText="Select slot start time" {...params} style={{ maxWidth: '20% !important' }} />}
                    /></LocalizationProvider></ThemeProvider> &nbsp;&nbsp;&nbsp;
                  <br></br><br></br>
                  <ThemeProvider theme={theme}>
                  <LocalizationProvider dateAdapter={AdapterDateFns} style={{ maxWidth: '20% !important' }}>
                    <MobileTimePicker
                      label="End Slot Time"
                      value={endTime}
                      style={{ maxWidth: '20% !important' }}
                      format="hh:mm:ss"
                      name="endTime"
                      onChange={(val) => handleEDateChange(pos, val)}
                      renderInput={(params) => <TextField 
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderColor: 'red',
                            },
                            '&:hover fieldset': {
                              borderColor: 'green',
                            },
                            '&.Mui-focused fieldset': {
                              borderColor: 'purple',
                            },
                          },
                        }}
                        helperText="Select slot end time" {...params} style={{ maxWidth: '20% !important' }} />}
                    /></LocalizationProvider>
                    </ThemeProvider>
                  &nbsp;&nbsp;&nbsp;
                  <FormControl required={true} variant="standard" style={{ textAlign: 'center', width: '100px' }}>
                    <TextField
                      id="standard-adornment-fname"
                      label="Slot Price($)"
                      helperText="Select slot price"
                      type={'text'}
                      value={amount}
                      onChange={(val) => handleAmountChange(pos, val)}
                      style={{ width: '100px' }} />
                  </FormControl>
                  &nbsp;&nbsp;&nbsp;
                  <Tooltip title="Delete slot">
                    <Button size="large">
                      <Image src={deletes} onClick={(e) => removeInputFields(pos)} style={{ float: 'right', height: '50px', cursor: 'pointer' }}></Image>
                    </Button>
                  </Tooltip>
                </Grid>
              </Grid>
            </Card><br></br>
          </>
        )
      }))
      }
    </>
  )
};