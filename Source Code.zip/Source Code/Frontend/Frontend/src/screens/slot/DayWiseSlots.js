import { Card, Checkbox, Typography } from "@mui/material";
import React, { useState } from "react";
import DayWiseSlotsDetails from "./DayWiseSlotsDetails";

export default function DayWiseSlots({ services, setPractice, practice, skipPublicHolidays, handleSkipPublicHolidayChange }) {

    const [inputFields, setInputFields] = useState([{
        day: '',
        service: '',
        amount: 0,
        timeRange: {
            startTime: '',
            endTime: ''
        }
    }]);
    return (
        <>
            {
                <><Card style={{ padding: '10px', backgroundColor: 'white' }}>
                    <Typography style={{ float: 'left', fontWeight: '700', padding: '20px 20px 0px 20px', }}>Daywise slots : </Typography>
                    <Checkbox
                        onChange={handleSkipPublicHolidayChange}
                        inputProps={{ 'aria-label': 'controlled' }}
                        checked={skipPublicHolidays}
                        style={{ marginTop: '10px' }}
                    />  <Typography style={{ padding: '20px 0px 0px 100px', float: 'left', fontWeight: '700' }}>Skip Federal Holidays</Typography>
                    <DayWiseSlotsDetails services={services} setInputFields={setInputFields} inputFields={inputFields} setPractice={setPractice} practice={practice} /><br></br>


                </Card><br></br>
                </>
            }
        </>
    );
};