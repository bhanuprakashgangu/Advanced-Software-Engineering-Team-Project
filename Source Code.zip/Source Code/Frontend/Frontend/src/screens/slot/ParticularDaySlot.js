import { Card, Typography } from "@mui/material";
import React, { useState } from "react";
import ParticularDaySlotDetails from "./ParticularDaySlotDetails";

export default function ParticularDaySlot({ services, setPractice, practice }) {

    const [inputFields, setInputFields] = useState([{
        date: '',
        service: '',
        amount: 0,
        timeRange: {
            startTime: '',
            endTime: ''
        }
    }]);
    return (
        <>
            {
                <><Card style={{ padding: '10px', backgroundColor: 'white' }}>
                    <Typography style={{ padding: '20px 20px 0px 20px', float: 'left', fontWeight: '700' }}>Particular day slots : </Typography>
                    <ParticularDaySlotDetails services={services} setInputFields={setInputFields} inputFields={inputFields} setPractice={setPractice} practice={practice} /><br></br>
                </Card><br></br>
                </>
            }
        </>
    );
};