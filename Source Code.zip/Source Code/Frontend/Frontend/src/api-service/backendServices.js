//This file is one -> it have all backend API calls
import axios from 'axios';
const BACKEND_APP_URL = "http://localhost:8080/api";



export const logoutUser = (userId) => {
  console.log("logoutUser called" + userId);
  return fetch(BACKEND_APP_URL + "/auth/signout/" + userId, {
    method: "POST",
    headers: { 'Content-Type': 'application/json' }
  });
}

export const registerUser = (fname, lname, email, password, role) => {
  console.log("register user called" + JSON.stringify({
    "firstName": fname,
    "lastName": lname,
    "password": password,
    "email": email,
    "role": role,
  }));
  return fetch(BACKEND_APP_URL + "/auth/signup", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      "firstName": fname,
      "lastName": lname,
      "password": password,
      "email": email,
      "role": role,
    })
  });
}
export const loginUser = (username, password) => {
  return fetch(BACKEND_APP_URL + "/auth/signin", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      "email": username,
      "password": password
    })
  });
}



export const getAllUsers = () => {
  return fetch(BACKEND_APP_URL + "/users_with_status", {
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  })
    .catch(error => {
      console.log("Error while getAllMovies");
    })
}

export const getUser = (email) => {
  return fetch(BACKEND_APP_URL + "/user/" + email, {
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}
export const editUsers = (fname, lname, email, password, role) => {
  console.log("register user called" + JSON.stringify({
    "firstName": fname,
    "lastName": lname,
    "password": password,
    "email": email,
    "role": role,
  }));
  return fetch(BACKEND_APP_URL + "/user/" + localStorage.getItem("userId"), {
    method: "PUT",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    body: JSON.stringify({
      "firstName": fname,
      "lastName": lname,
      "password": password,
      "email": email,
      "role": role,
    })
  });
}

export const addService = (serviceName) => {
  console.log("addService called" + JSON.stringify({
    "name": serviceName,
    "userId": localStorage.getItem("userId")
  }));
  return axios({
    url: BACKEND_APP_URL + "/service",
    method: "POST",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    data: JSON.stringify({
      "name": serviceName,
      "userId": localStorage.getItem("userId")
    })
  });
}

export const editServices = (serviceId, serviceName) => {
  console.log("editServices called" + JSON.stringify({
    "serviceName": serviceName,
    "userId": localStorage.getItem("userId")
  }));
  return axios({
    url: BACKEND_APP_URL + "/service/" + serviceId,
    method: "PUT",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    data: JSON.stringify({
      "name": serviceName,
      "userId": localStorage.getItem("userId")
    })
  });
}

export const getAllServices = () => {
  return axios({
    url: BACKEND_APP_URL + "/service",
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

export const deleteServices = (id) => {
  return axios({
    url: BACKEND_APP_URL + "/service/" + id + "/" + localStorage.getItem("userId"),
    method: "DELETE",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

export const getAllHospitalDetails = (name) => {
  return fetch(BACKEND_APP_URL + "/hospitals/allhospitals?search=" + name, {
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  })
    .catch(error => {
      console.log("Error while getAllHospitalDetails");
    })
}

export const addHospital = (hospitalName, street, zip, city, state, country, slotList, selectValue) => {

  return fetch(BACKEND_APP_URL + "/hospitals", {
    method: "POST",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    body: JSON.stringify({
      "hospitalName": hospitalName,
      "street": street,
      "city": city,
      "state": state,
      "zipcode": zip,
      "country": country,
      "serviceList": selectValue,
      "slotList": slotList,
      "userId": localStorage.getItem("userId"),

    })
  });
}


export const deleteHospitals = (id) => {
  return fetch(BACKEND_APP_URL + "/hospitals/" + id + "/" + localStorage.getItem("userId"), {
    method: "DELETE",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

export const editHospital = (hospitalId, hospitalName, street, city, state, country, zip, selectValue) => {
  console.log("editHospitals called" + JSON.stringify({
    "hospitalName": hospitalName,
    "street": street,
    "city": city,
    "state": state,
    "zipcode": zip,
    "country": country,
    "serviceList": selectValue,
  }));
  return fetch(BACKEND_APP_URL + "/hospitals/" + hospitalId + "/" + localStorage.getItem("userId"), {
    method: "PUT",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    body: JSON.stringify({
      "hospitalName": hospitalName,
      "street": street,
      "city": city,
      "state": state,
      "zipcode": zip,
      "country": country,
      "serviceList": selectValue,
    })
  });
}

export const saveSlotsToHospital = (hospitalId, slotList) => {
  console.log("editHospitals called" + JSON.stringify({
    "slotList": slotList,

  }));
  return fetch(BACKEND_APP_URL + "/hospitals/slots/" + hospitalId + "/" + localStorage.getItem("userId"), {
    method: "PUT",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    body: JSON.stringify({
      "slotList": slotList,
    })
  });
}


export const bookSlotForHospital = (hospitalId, slotId, message, payment, cardDetails) => {
  return fetch(BACKEND_APP_URL + "/slot/book", {
    method: "POST",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
    body: JSON.stringify({
      "slotId": slotId,
      "hospitalId": hospitalId,
      "message": message,
      "userId": localStorage.getItem("userId"),
      "paymentType": payment ? payment : "-",
      "paymentId": cardDetails ? cardDetails : "-",
      "status": "BOOKED"
    })
  });
}

export const cancelSlotForHospital = (slotId) => {
  return fetch(BACKEND_APP_URL + "/slot/cancel/" + slotId + "/" + localStorage.getItem("userId"), {
    method: "POST",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },

  });
}

export const deleteSlotsToHospital = (hospitalId, slotId) => {
  return fetch(BACKEND_APP_URL + "/hospitals/slots/" + slotId + "/" + hospitalId + "/" + localStorage.getItem("userId"), {
    method: "DELETE",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}


export const getAllBookings = () => {
  return fetch(BACKEND_APP_URL + "/slot/" + localStorage.getItem("userId"), {
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

export const getAllSlotsBetweenDates = (hId, sdate, edate) => {
  return axios({
    url: BACKEND_APP_URL + "/slot/" + hId + "/" + sdate + "/" + edate,
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

export const getHospitalById = (hospitalId) => {
  return fetch(BACKEND_APP_URL + "/hospitals/" + hospitalId, {
    method: "GET",
    headers: { 'Content-Type': 'application/json', 'token': '' + localStorage.getItem('token') },
  });
}

